import {readFile,writeFile} from "node:fs/promises";
import {PGlite} from "@electric-sql/pglite";
import {postgis} from "@electric-sql/pglite-postgis";
const root = new URL("../",import.meta.url);
const read = name => readFile(new URL(name,root),"utf8");
const sql = async name => (await read("sql/"+name)).replace(/^\\set .*$/gm,"");
const release = JSON.parse(await read("data/canonical_snapshot.json")).release.release_id;
const db = new PGlite({extensions:{postgis}});
try {
  const priorPath=process.argv[2];
  const lockedGeometryQuery = `SELECT
    (SELECT md5(string_agg(ST_AsEWKB(geom)::text,'' ORDER BY feature_id)) FROM educity_f3.floorplate) AS floorplate,
    (SELECT md5(string_agg(ST_AsEWKB(geom)::text,'' ORDER BY zone_id)) FROM educity_f3.zones) AS zones,
    (SELECT md5(string_agg(ST_AsEWKB(geom)::text,'' ORDER BY feature_id)) FROM educity_f3.stair_features) AS stairs,
    (SELECT md5(string_agg(ST_AsEWKB(geom)::text,'' ORDER BY sign_id)) FROM educity_f3.exit_signs) AS signs`;
  let prior;
  if (priorPath) {
    await db.exec((await readFile(priorPath,"utf8")).replace(/^\\set .*$/gm,""));
    prior=(await db.query(lockedGeometryQuery)).rows[0];
  }
  await db.exec(await sql("99_standalone_full_load.sql"));
  const locked=(await db.query(lockedGeometryQuery)).rows[0];
  if (prior && JSON.stringify(prior)!==JSON.stringify(locked)) throw Error("Upgrade changed existing geometry: "+JSON.stringify({prior,locked}));
  const results = await db.query("SELECT * FROM educity_f3.v_release_qa WHERE release_id=$1 ORDER BY check_name",[release]);
  if (results.rows.length !== 32 || results.rows.some(row => !row.pass)) throw Error("SQL QA failed");
  const viewsQuery = `SELECT (SELECT count(*) FROM educity_f3.v_egress_signs WHERE geom IS NOT NULL)::int AS sign_view,
    (SELECT count(*) FROM educity_f3.v_stair_inventory)::int AS stair_inventory,
    (SELECT count(*) FROM educity_f3.v_lift_shafts)::int AS lift_shafts,
    (SELECT count(*) FROM educity_f3.v_zone_summary)::int AS zone_view,
    (SELECT count(*) FROM educity_f3.v_entrance_egress)::int AS entrance_view,
    (SELECT count(*) FROM educity_f3.v_room_door_access)::int AS door_access_view,
    (SELECT count(*) FROM educity_f3.v_stair_flights)::int AS stair_flight_view`;
  const views = (await db.query(viewsQuery)).rows[0];
  if (views.sign_view!==16 || views.stair_inventory!==4 || views.lift_shafts!==4 || views.zone_view!==52 || views.entrance_view!==3 || views.door_access_view!==136 || views.stair_flight_view!==14) {
    throw Error("Display view counts differ");
  }
  const geojson = JSON.parse(await read("geojson/exit_signs.geojson")).features;
  const signs = (await db.query("SELECT sign_id,ST_X(geom) AS x,ST_Y(geom) AS y FROM educity_f3.exit_signs ORDER BY sign_id")).rows;
  for (const {sign_id,x,y} of signs) {
    const [lon,lat] = geojson.find(f=>f.properties.sign_id===sign_id).geometry.coordinates;
    if (Math.hypot(x-lon,y-lat)>1e-11) throw Error("Sign moved across formats: "+sign_id);
  }
  await db.exec(await sql("99_standalone_full_load.sql"));
  const reloaded = (await db.query(viewsQuery)).rows[0];
  if (JSON.stringify(views)!==JSON.stringify(reloaded)) throw Error("Reload changed view counts");
  const engine = (await db.query("SELECT version() AS postgres, postgis_full_version() AS postgis")).rows[0];
  const report = {release,status:"PASS",
    summary:`${results.rows.length} SQL checks passed; standalone loader succeeded twice.`,
    engine,checks:results.rows,views,
    standalone_load_runs:2,repeat_load_pass:true,exit_sign_coordinates_match_geojson:true,
    baseline_geometries_unchanged:prior?true:null,locked_geometry_ewkb_hashes:locked};
  await writeFile(new URL("qa/postgis_validation.json",root),JSON.stringify(report,null,2)+"\n");
  console.log(JSON.stringify({checks:results.rows.length,views,repeat_load_pass:true}));
} catch (error) {
  console.error(error.message,error.code??"",error.position??"");
  process.exitCode=1;
} finally {
  await db.close();
}
