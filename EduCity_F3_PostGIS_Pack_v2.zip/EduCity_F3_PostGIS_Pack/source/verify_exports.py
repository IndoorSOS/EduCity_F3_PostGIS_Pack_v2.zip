"""Check coordinate agreement and layer completeness across GIS exports."""
import csv
from hashlib import sha256
import json
import sqlite3
from pathlib import Path
from xml.etree import ElementTree as ET

from pyogrio import list_layers
from pyogrio.raw import read
from pyproj import Transformer
from shapely import from_wkb, transform
from shapely.geometry import shape

ROOT = Path(__file__).resolve().parents[1]
TO_GRID = Transformer.from_crs(4326, 3877, always_xy=True)
LAYERS = {
    "floorplate": ("feature_id", 1), "floorplate_vertices": ("point_id", 30),
    "zones": ("zone_id", 52), "vertices": ("point_id", 340),
    "zone_wall_segments": ("segment_id", 340), "lift_cars": ("feature_id", 0),
    "stair_features": ("feature_id", 4), "exit_signs": ("sign_id", 16),
    "egress_links": ("egress_id", 16), "single_doors": ("feature_id", 0), "door_access": ("feature_id", 136),
    "stair_flight_detail": ("feature_id", 113),
}
GPKG = ROOT / "EduCity_F3.gpkg"
counts = {layer: expected for layer, (_, expected) in LAYERS.items()}
assert {name for name, _ in list_layers(GPKG)} == {name for name,count in counts.items() if count}
max_offset = 0
for layer, (id_field, expected) in LAYERS.items():
    geo = json.loads((ROOT / f"geojson/{layer}.geojson").read_text())["features"]
    with (ROOT / f"data/{layer}.csv").open(newline="", encoding="utf-8") as file:
        rows = list(csv.DictReader(file))
    assert len(geo) == len(rows) == expected
    if not expected:
        continue
    meta, _, geometries, attributes = read(GPKG, layer=layer)
    assert meta["crs"] == "EPSG:3877" and len(geometries) == expected
    ids = attributes[list(meta["fields"]).index(id_field)]
    stored = dict(zip(ids, from_wkb(geometries)))
    assert len(stored) == expected and set(stored) == {row[id_field] for row in rows}
    for feature in geo:
        g = shape(feature["geometry"])
        projected = transform(g, TO_GRID.transform, interleaved=False)
        got = stored[feature["properties"][id_field]]
        assert g.is_valid and projected.is_valid and got.is_valid
        assert g.geom_type == got.geom_type == meta["geometry_type"]
        max_offset = max(max_offset, projected.hausdorff_distance(got))
assert max_offset < 1e-6
with sqlite3.connect(GPKG) as gpkg:
    assert gpkg.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
full = json.loads((ROOT / "geojson/EduCity_F3_Full.geojson").read_text())["features"]
assert len(full) == sum(counts.values())
ns = {"k": "http://www.opengis.net/kml/2.2"}
tree = ET.parse(ROOT / "EduCity_F3.kml")
folders = {f.find("k:name", ns).text: len(f.findall("k:Placemark", ns))
           for f in tree.findall(".//k:Folder", ns)}
assert folders == {key: counts[key] for key in ("floorplate", "zones", "exit_signs", "stair_features", "door_access", "stair_flight_detail")}
locks = json.loads((ROOT / "source/locked_geojson_sha256.json").read_text())
for name, digest in locks.items():
    assert sha256((ROOT / name).read_bytes()).hexdigest() == digest, f"Frozen layer changed: {name}"
postgis = json.loads((ROOT / "qa/postgis_validation.json").read_text())
report = {"frozen_geojson_layers_byte_identical": list(locks), "layer_feature_counts": counts, "geopackage_crs": "EPSG:3877",
          "geojson_crs": "EPSG:4326", "max_reprojected_geometry_distance_m": max_offset,
          "geopackage_integrity": "ok", "csv_ids_match_geopackage": True, "kml_folder_counts": folders,
          "postgis_validation": {"status": postgis.get("status"),
              "checks_passed": sum(1 for check in postgis.get("checks", []) if check.get("pass")),
              "standalone_load_runs": postgis.get("standalone_load_runs"),
              "repeat_load_pass": postgis.get("repeat_load_pass")}}
(ROOT / "qa/export_validation.json").write_text(json.dumps(report, indent=2)+"\n")
print(json.dumps(report))
