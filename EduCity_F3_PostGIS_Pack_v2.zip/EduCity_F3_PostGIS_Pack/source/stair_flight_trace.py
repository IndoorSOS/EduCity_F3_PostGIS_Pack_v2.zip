"""Build source-derived stair polygons without assuming vertical connections."""
import csv
from pathlib import Path

from shapely.geometry import Polygon


def trace_stairs(path: Path, offset, project):
    with path.open(newline="", encoding="utf-8") as file:
        for row in csv.DictReader(file):
            zone, part = row["zone"], row["position"]
            kind = row["feature"]
            boundaries = [float(v) for v in row["boundaries"].split()]
            cross_a, cross_b = float(row["low_cross"]), float(row["high_cross"])
            if boundaries != sorted(set(boundaries)) or len(boundaries) < 2 or cross_a >= cross_b:
                raise ValueError(f"Invalid stair picks in {zone}/{part}/{kind}")
            axis = row["axis"]

            def polygon(a, b):
                x0, y0, x1, y1 = (a, cross_a, b, cross_b) if axis == "x" else (cross_a, a, cross_b, b)
                return Polygon([project((x-offset[0], y-offset[1]))
                                for x, y in [(x0,y0), (x1,y0), (x1,y1), (x0,y1)]])

            parent = f"EDU-F3-{zone}"
            fid = f"{parent}-{part}-{kind.upper()}"
            info = {
                "feature_id": fid, "parent_zone_id": parent, "feature_type": f"stair_{kind}",
                "plan_position": part, "source_visibility": row["visibility"],
                "travel_direction_status": "unverified",
            }
            yield info | {
                "flight_id": fid if kind == "flight" else None,
                "visible_tread_count": len(boundaries)-1 if kind == "flight" else None,
            }, polygon(boundaries[0], boundaries[-1])
            if kind == "flight":
                for number, (a, b) in enumerate(zip(boundaries, boundaries[1:]), 1):
                    yield info | {
                        "feature_id": f"{fid}-T{number:02}", "feature_type": "stair_tread",
                        "flight_id": fid, "tread_index": number,
                    }, polygon(a, b)
