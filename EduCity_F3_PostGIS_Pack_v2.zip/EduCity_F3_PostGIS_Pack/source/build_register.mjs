import { readFile, mkdir, writeFile } from "node:fs/promises";
import { Workbook, SpreadsheetFile } from "@oai/artifact-tool";

const [specPath, outputPath, previewDirectory] = process.argv.slice(2);
const spec = JSON.parse(await readFile(specPath, "utf8"));
const workbook = Workbook.create();
const guide = new Set(["Summary", "Read Me"]);

function columnName(index) {
  let label = "";
  for (let value=index+1; value>0; value=Math.floor((value-1)/26)) {
    label = String.fromCharCode(65+(value-1)%26)+label;
  }
  return label;
}

function width(header) {
  if (header === "Item" || header === "Topic") return 27;
  if (header === "Value" || header === "Detail") return 75;
  if (header === "geom" || header === "swing_geom") return 46;
  if (/check_name|description|position_status|geometry_basis|route_status|travel_direction_status|note|location|access_ids/.test(header)) return 47;
  if (/release_id|space|address|review_state|rendering/.test(header)) return 34;
  if (/_id$/.test(header)) return 23;
  return Math.max(14, Math.min(24, header.length+3));
}

for (const {name,subtitle,rows} of spec) {
  const sheet = workbook.worksheets.add(name);
  const lastColumn = columnName(rows[0].length-1);
  const finalRow = rows.length+3;
  const used = sheet.getRange(`A2:${lastColumn}${finalRow}`);
  used.format.font.name = "Aptos";
  used.format.font.size = 10;
  used.format.font.color = "#173143";
  for (const [index, header] of rows[0].entries()) {
    const column = columnName(index);
    sheet.getRange(`${column}:${column}`).format.columnWidth = name.startsWith("Stair ") && ["feature_id","flight_id"].includes(header) ? 37 : width(header);
  }
  for (const [row, value, fill, color] of [
    [2, `EduCity F3 · ${name}`, "#132e42", "#FFFFFF"],
    [3, subtitle, "#DDECEB", "#1D504E"],
  ]) {
    const banner=sheet.getRange(`A${row}:${columnName(Math.min(rows[0].length-1,5))}${row}`);
    banner.merge();
    banner.values=[[value]];
    banner.format.fill=fill;
    banner.format.font.color=color;
    banner.format.font.bold=true;
    banner.format.font.size=row===2?16:10;
    banner.format.rowHeight=row===2?28:23;
  }
  sheet.getRange(`A4:${lastColumn}${finalRow}`).values = rows;
  const header=sheet.getRange(`A4:${lastColumn}4`);
  header.format.fill = "#176466";
  header.format.font.color = "#FFFFFF";
  header.format.font.bold = true;
  header.format.rowHeight = 24;
  if (finalRow>=5) {
    const body=sheet.getRange(`A5:${lastColumn}${finalRow}`);
    body.format.rowHeight=18;
    sheet.getRange(`A5:${lastColumn}${finalRow}`).format.fill = "#FFFFFF";
    for (let row=6;row<=finalRow;row+=2) {
      sheet.getRange(`A${row}:${lastColumn}${row}`).format.fill="#EFF6F7";
    }
    rows[0].forEach((field,index)=>{
      const col=columnName(index);
      if (field==="longitude" || field==="latitude") {
        sheet.getRange(`${col}5:${col}${finalRow}`).setNumberFormat("0.000000000");
      }
      if (/_(m|m2|deg)$/.test(field)) {
        sheet.getRange(`${col}5:${col}${finalRow}`).setNumberFormat("0.000");
      }
      if (field==="geom" || field==="swing_geom" || field==="note") {
        sheet.getRange(`${col}5:${col}${finalRow}`).format.wrapText=true;
      }
    });
  }
  sheet.freezePanes.freezeRows(4);
  if (guide.has(name)) sheet.getRange(`A5:A${finalRow}`).format.font.bold=true;
}
workbook.recalculate();
if (previewDirectory) {
  await mkdir(previewDirectory, {recursive:true});
  for (const {name,rows} of spec) {
    const end = columnName(Math.min(rows[0].length, 7)-1);
    const range = `A2:${end}${Math.min(rows.length+3, name==="Summary"?23:12)}`;
    const rendered = await workbook.render({sheetName:name,range,scale:1,format:"png"});
    await writeFile(`${previewDirectory}/${name.replaceAll(" ","_")}.png`,new Uint8Array(await rendered.arrayBuffer()));
  }
}
const xlsx=await SpreadsheetFile.exportXlsx(workbook);
await xlsx.save(outputPath);
