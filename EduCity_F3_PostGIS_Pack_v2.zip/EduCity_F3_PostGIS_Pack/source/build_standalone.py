"""Combine the split SQL files in dependency order as a single atomic loader."""
from pathlib import Path

sql = Path(__file__).resolve().parents[1] / "sql"
steps = ("00_schema.sql", "01_load.sql", "03_views.sql", "02_validate.sql")
lines = ["\\set ON_ERROR_STOP on", "BEGIN;",
         "SELECT pg_advisory_xact_lock(hashtext('educity_f3'));"]
for name in steps:
    lines.append(f"\n-- {name}")
    for line in (sql / name).read_text(encoding="utf-8").splitlines():
        if line.startswith("\\set ") or line in ("BEGIN;", "COMMIT;"):
            continue
        if line == "SELECT pg_advisory_xact_lock(hashtext('educity_f3'));":
            continue
        lines.append(line)
(sql / "99_standalone_full_load.sql").write_text(
    "\n".join([*lines, "", "COMMIT;", ""]), encoding="utf-8"
)
