"""Write the sign display register and synchronize the satellite review."""
import csv
import html
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read_signs():
    source = json.loads((ROOT / "source/approved_trace.json").read_text(encoding="utf-8"))
    return sorted(source["exit_signs"], key=lambda row: int(row["sign_id"].rsplit("-", 1)[1]))


def display_rows(signs):
    for sign in signs:
        axis = sign.get("threshold_true_axis_deg")
        yield {
            "sign_id": sign["sign_id"],
            "access_id": sign["access_id"],
            "svg_rotation_deg": sign["rotation_deg"],
            "drawing_rotation_deg": sign["drawing_rotation_deg"],
            "threshold_true_axis_deg": axis,
            "crossing_true_axis_deg": sign.get("crossing_true_axis_deg"),
            "housing_display_basis": sign.get("housing_display_basis", "approved_preview_orientation"),
            "travel_direction_status": sign.get("travel_direction_status", "unverified"),
            "fw_adv_id": sign.get("fw_adv_id", ""),
        }


def write_register(rows):
    rows = list(rows)
    with (ROOT / "data/exit_sign_display.csv").open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def update_satellite_review(signs):
    path = ROOT / "assets/EduCity_F3_Satellite_Review.html"
    original = path.read_text(encoding="utf-8")
    active = {row["sign_id"] for row in signs}
    pattern = re.compile(r'<g class="exit-sign" data-sign="([^"]+)"[^>]*>.*?</g>', re.S)
    original = pattern.sub(lambda match: "" if match.group(1) not in active else match.group(0), original)
    for sign in signs:
        sid = sign["sign_id"]
        x, y = float(sign["x_px"]), float(sign["y_px"])
        rotation = float(sign["drawing_rotation_deg"])
        detail = html.escape(f'{sid} · {sign["description"]}', quote=True)
        transform = f'translate({x:.6f} {y:.6f}) scale(1.65) translate({-x:.6f} {-y:.6f})'
        group_pattern = re.compile(rf'(<g class="exit-sign" data-sign="{re.escape(sid)}"[^>]*>).*?</g>', re.S)
        match = group_pattern.search(original)
        if not match:
            raise ValueError(f"Satellite sign is missing: {sid}")
        block = match.group(0)
        head = block.split(">", 1)[0] + ">"
        head = re.sub(r'aria-label="[^"]*"', f'aria-label="{detail}"', head)
        head = re.sub(r'transform="[^"]*"', f'transform="{transform}"', head)
        block = head + block[len(block.split(">", 1)[0]) + 1:]
        block = re.sub(r'<title>.*?</title>', f'<title>{html.escape(sid + " — " + sign["description"])}</title>', block, count=1, flags=re.S)
        rect_x, rect_y = x - 10.7, y - 6.3
        use_x, use_y = x - 10.0, y - 5.555
        rot = f'rotate({rotation:.6f} {x:.6f} {y:.6f})'
        block = re.sub(r'<rect class="signHit"[^>]*>',
            f'<rect class="signHit" x="{rect_x:.4f}" y="{rect_y:.4f}" width="21.4" height="12.6" rx=".8" fill="transparent" transform="{rot}"/>', block, count=1)
        block = re.sub(r'<use x="[^"]+" y="[^"]+" href="#satellite-fixture-icon"[^>]*>',
            f'<use x="{use_x:.4f}" y="{use_y:.4f}" href="#satellite-fixture-icon" transform="{rot}" pointer-events="none"/>', block, count=1)
        original = original[:match.start()] + block + original[match.end():]
    path.write_text(original, encoding="utf-8")


def main():
    signs = read_signs()
    rows = list(display_rows(signs))
    write_register(rows)
    update_satellite_review(signs)


if __name__ == "__main__":
    main()
