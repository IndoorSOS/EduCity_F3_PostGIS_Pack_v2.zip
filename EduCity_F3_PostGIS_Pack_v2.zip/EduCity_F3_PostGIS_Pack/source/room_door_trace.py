"""Convert door jamb picks in source-image coordinates into metric linework."""
import csv
import math

from shapely.geometry import LineString

SWING = {"left": (-1, 0), "right": (1, 0), "up": (0, -1), "down": (0, 1)}


def trace_doors(path, source_offset, project, zone_ids):
    with path.open(newline="", encoding="utf-8") as file:
        rows = list(csv.DictReader(file))
    for row in rows:
        access = f"EDU-F3-DA-{int(row['access_no']):02}"
        zone = "EDU-F3-" + row["zone"]
        adjacent = "EDU-F3-" + row["adjacent_zone"] if row["adjacent_zone"] else None
        if zone not in zone_ids or (adjacent and adjacent not in zone_ids):
            raise ValueError(f"Unknown zone in {access}")
        a, b = [
            tuple(float(row[f"{axis}{i}"]) - offset for axis, offset in zip("xy", source_offset))
            for i in (1, 2)
        ]
        threshold = LineString([project(a), project(b)])
        length = math.dist(a, b)
        kind = row["kind"]
        sign = int(row["exit_no"]) if row["exit_no"] else None
        leaf_count = {"": 0, "first": 1, "second": 1, "both": 2}[row["hinge"]]
        types = {"gap": "opening_only", "lift": "lift_entrance",
                 "door": "double_leaf_door" if leaf_count == 2 else "single_leaf_door"}
        props = {
            "access_id": access, "zone_id": zone, "adjacent_zone_id": adjacent,
            "egress_id": f"EDU-F3-EG-{sign:02}" if sign else None,
            "sign_id": f"EDU-F3-ES-{sign:02}" if sign else None,
            "feature_type": types[kind], "location": row["location"],
            "swing_toward": f"image_{row['swing_side']}" if leaf_count else None,
            "review_state": "source_gap_review" if kind == "gap" else "draft_trace",
        }
        yield props | {"feature_id": access+"-threshold", "part": "threshold",
                       "opening_m": round(threshold.length, 3)}, threshold
        if kind != "door":
            continue
        direction = ((b[0]-a[0])/length, (b[1]-a[1])/length)
        side = SWING[row["swing_side"]]
        if abs(direction[0]*side[0] + direction[1]*side[1]) > 1e-6:
            raise ValueError(f"Swing vector is not perpendicular to the threshold of {access}")
        fraction = float(row["first_leaf_fraction"]) if leaf_count == 2 else 1
        leaves = {
            "first": (("leaf_1_swing", a, 1, 1),),
            "second": (("leaf_2_swing", b, -1, 1),),
            "both": (("leaf_1_swing", a, 1, fraction), ("leaf_2_swing", b, -1, 1-fraction)),
        }
        for part, hinge, sense, span in leaves[row["hinge"]]:
            radius = span * length
            points = [hinge]
            for i in range(13):
                theta = math.pi*i/24
                points.append(tuple(hinge[j] + radius*(side[j]*math.cos(theta)
                                   + sense*direction[j]*math.sin(theta)) for j in (0, 1)))
            yield props | {"feature_id": access+"-"+part, "part": part, "opening_m": None}, LineString(
                [project(p) for p in points]
            )


def zone_coverage(zones, access, notes):
    by_zone = {z["id"]: [] for z in zones}
    for row in access:
        if row["part"] != "threshold":
            continue
        for zid in (row["zone_id"], row.get("adjacent_zone_id")):
            if zid:
                by_zone[zid].append(row)
    for zone in zones:
        zid = zone["id"]
        found = by_zone[zid]
        swings = sum(row["feature_type"] in {"single_leaf_door","double_leaf_door"} for row in found)
        gap = sum(row["feature_type"] == "opening_only" for row in found)
        lift = sum(row["feature_type"] == "lift_entrance" for row in found)
        note = notes.get(zid.removeprefix("EDU-F3-"), "")
        status = "drawn_swing_traced" if swings else (
            "lift_entrance_traced" if lift else "opening_only_review" if gap else "no_distinct_door_traced"
        )
        if not found and not note:
            raise ValueError(f"No door disposition for {zid}")
        yield {"zone_id": zid, "space": zone["name"], "door_access_count": len(found),
               "swing_access_count": swings, "opening_only_count": gap, "lift_entrance_count": lift,
               "review_state": status, "note": note,
               "access_ids": ", ".join(row["access_id"] for row in found)}
