"""Build the EduCity F3 PostGIS release from the approved trace and mapped controls."""
from collections import Counter
from itertools import combinations
from pathlib import Path
from xml.etree import ElementTree as ET
import csv
import json
import math

import numpy as np
from pyogrio.raw import write as write_vector
from pyproj import Transformer
from shapely.geometry import LineString, Point, Polygon, mapping, shape
from shapely.geometry.polygon import orient
from shapely import to_wkt, transform

from room_door_trace import trace_doors, zone_coverage
from stair_flight_trace import trace_stairs

ROOT = Path(__file__).resolve().parents[1]
DATA, GEO, SQL = (ROOT / n for n in ("data", "geojson", "sql"))
RELEASE = "educity-f3-20261105-postgis-v2"
SITE = "EDUCITY-TURKU"
DATE = "2026-11-05"
CRS = "EPSG:4326"
METRIC = "EPSG:3877"
STATE = "draft_footprint_registered"
BASE = {"release_id": RELEASE, "site_id": SITE, "level_id": "F3"}
SOURCE_OFFSET = (857, 70)
FLOOR_ID = "EDU-F3-FLOORPLATE-01"
OSM_URL = "https://www.openstreetmap.org/way/731925812"
LAYER_ORDER = (
    "floorplate", "floorplate_vertices", "zones", "vertices", "zone_wall_segments",
    "lift_cars", "stair_features", "exit_signs", "egress_links", "single_doors", "door_access", "stair_flight_detail",
)
KINDS = {
    "floorplate": "Polygon", "floorplate_vertices": "Point", "zones": "Polygon",
    "vertices": "Point", "zone_wall_segments": "LineString", "lift_cars": "Polygon",
    "stair_features": "Polygon", "exit_signs": "Point", "egress_links": "Point",
    "single_doors": "LineString", "door_access": "LineString", "stair_flight_detail": "Polygon",
}
STAIR_DETAIL_FIELDS = [
    "release_id", "site_id", "level_id", "feature_id", "parent_zone_id", "feature_type",
    "plan_position", "flight_id", "tread_index", "visible_tread_count",
    "source_visibility", "travel_direction_status", "area_m2", "perimeter_m", "geom",
]
DOOR_ACCESS_FIELDS = [
    "release_id", "site_id", "level_id", "feature_id", "access_id", "zone_id", "egress_id", "sign_id",
    "feature_type", "part", "location", "swing_toward", "opening_m", "review_state", "geom",
    "adjacent_zone_id",
]
EXTRA = {
    "zones": ["source_name_en", "source_name_fi", "note"],
    "vertices": ["ring_index", "ring_point_no"],
    "zone_wall_segments": ["ring_index"],
    "exit_signs": ["zone_id", "position_status"],
    "egress_links": ["route_status"],
}


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def csv_out(path, fields, records):
    with path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(records)


def feature(properties, geometry):
    return {"type": "Feature", "properties": properties, "geometry": mapping(geometry)}


def collection(features):
    return {"type": "FeatureCollection", "features": features}


def literal(value, field):
    if value is None or value == "":
        return "NULL"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)):
        return str(value)
    quoted = "'" + value.replace("'", "''") + "'"
    return "ST_GeomFromEWKT(" + quoted + ")" if field in {"geom", "swing_geom"} else quoted


def noded_ring(ring, candidates):
    """Split common boundaries at existing T-junctions before projection."""
    result = []
    for a, b in zip(ring, ring[1:] + ring[:1]):
        a = tuple(a)
        dx, dy = b[0] - a[0], b[1] - a[1]
        length2 = dx * dx + dy * dy
        if length2 == 0:
            raise ValueError("Repeated adjacent ring vertices")
        interior = []
        for x, y in candidates:
            u, v = x - a[0], y - a[1]
            if abs(u * dy - v * dx) > 1e-7:
                continue
            t = (u * dx + v * dy) / length2
            if 1e-9 < t < 1 - 1e-9:
                interior.append((t, (x, y)))
        result.append(a)
        result.extend(p for _, p in sorted(interior))
    return result


def main():
    raw = read_json(ROOT / "source/approved_trace.json")
    osm = read_json(ROOT / "source/footprint_osm.json")
    columns = read_json(ROOT / "source/f7_column_contract.json")
    columns["door_access"] = DOOR_ACCESS_FIELDS
    columns["stair_flight_detail"] = STAIR_DETAIL_FIELDS
    for name, fields in EXTRA.items():
        columns[name] += fields
    osm_nodes = {n["id"]: n for n in osm["elements"] if n["type"] == "node"}
    osm_way = next(n for n in osm["elements"] if n["type"] == "way")
    assert osm_way["id"] == 731925812 and osm_way["tags"]["addr:housenumber"] == "7"
    to_grid = Transformer.from_crs(CRS, METRIC, always_xy=True)
    to_wgs = Transformer.from_crs(METRIC, CRS, always_xy=True)
    plan_control = np.array([[0, 0], [632, 0], [632, 800], [0, 800]], dtype=float)
    control_ids = [6853867342, 6853867341, 6853867344, 6853867343]
    control_ll = [(osm_nodes[n]["lon"], osm_nodes[n]["lat"]) for n in control_ids]
    control_grid = np.array([to_grid.transform(*p) for p in control_ll])
    centroid = control_grid.mean(axis=0)
    design = np.column_stack([plan_control, np.ones(4)])
    affine = np.linalg.lstsq(design, control_grid - centroid, rcond=None)[0]
    affine[2] += centroid
    errors = np.linalg.norm(design @ affine - control_grid, axis=1)

    def project(p):
        return tuple(np.array([*p, 1.0]) @ affine)

    def geographic(g):
        out = transform(g, to_wgs.transform, interleaved=False)
        return orient(out, sign=1.0) if out.geom_type == "Polygon" else out

    original = raw["zones"]
    floor_ring = [(0, 0), (632, 0), (632, 800), (0, 800), (0, 423), (-88, 423), (-88, 380), (0, 380)]
    nodes = {tuple(p) for z in original for ring in z["rings"] for p in ring} | set(floor_ring)
    floor_nodes = noded_ring(floor_ring, nodes)
    polygon = Polygon([project(p) for p in floor_nodes])
    node_ring_map = {
        z["id"]: [noded_ring(ring, nodes) for ring in z["rings"]] for z in original
    }
    zone_polygons = {
        zid: Polygon([project(p) for p in rings[0]], [[project(p) for p in r] for r in rings[1:]])
        for zid, rings in node_ring_map.items()
    }
    for p in [polygon, *zone_polygons.values()]:
        if not p.is_valid or p.is_empty:
            raise ValueError("Invalid polygon in the projected trace")
    max_overlap = max((a.intersection(b).area for a, b in combinations(zone_polygons.values(), 2)), default=0.0)
    max_escape = max(p.difference(polygon).area for p in zone_polygons.values())
    assert max_overlap < 1e-6 and max_escape < 1e-6

    records = {t: [] for t in LAYER_ORDER}
    layers = {t: [] for t in LAYER_ORDER}
    grid_layers = {t: [] for t in LAYER_ORDER}

    def add(table, props, geometry, sql_geometry=True):
        props = BASE | props
        wgs = geographic(geometry)
        record = dict(props)
        if sql_geometry:
            record["geom"] = "SRID=4326;" + to_wkt(wgs, rounding_precision=12)
        records[table].append(record)
        layers[table].append(feature(props, wgs))
        grid_layers[table].append(geometry)

    def xy(p):
        lon, lat = to_wgs.transform(*project(p))
        return dict(screen_x=p[0], screen_y=p[1], source_x=p[0]+SOURCE_OFFSET[0],
                    source_y=p[1]+SOURCE_OFFSET[1], longitude=round(lon, 12), latitude=round(lat, 12))

    def measures(p):
        return dict(area_m2=round(p.area, 3), perimeter_m=round(p.length, 3))

    north = max(floor_nodes, key=lambda p: project(p)[1])
    add("floorplate", dict(feature_id=FLOOR_ID, feature_type="floorplate", vertex_count=len(floor_nodes),
                           north_apex_screen_x=north[0], north_apex_screen_y=north[1],
                           boundary_rendering="solid_cyan_outline", review_state=STATE, as_of_date=DATE) |
        measures(polygon), polygon)
    for i, p in enumerate(floor_nodes, 1):
        add("floorplate_vertices", dict(feature_id=FLOOR_ID, vertex_no=i,
            point_id=f"EDU-F3-FP-V{i:02}", sequence="approved_trace_order") | xy(p), Point(project(p)))

    sign_list = raw["exit_signs"]
    sign_count = Counter(s["zone_id"] for s in sign_list)
    global_point = 0
    for i, z in enumerate(original, 1):
        zid = z["id"]
        p = zone_polygons[zid]
        rings = node_ring_map[zid]
        n = sum(map(len, rings))
        add("zones", dict(level_name="Floor 3", floor_elevation_m=None, zone_no=i, zone_id=zid,
            space=z["name"], category=z["kind"], shape="polygon_with_holes" if len(rings)>1 else "polygon",
            vertex_count=n, egress_profile_count=0, egress_link_count=sign_count[zid],
            display_color=z["color"], review_state=STATE, as_of_date=DATE,
            source_name_en=z.get("source_name_en"), source_name_fi=z.get("source_name_fi"), note=z["note"]) |
            measures(p), p)
        zone_point = 0
        for ri, ring in enumerate(rings):
            originals = {tuple(point) for point in z["rings"][ri]}
            point_ids = []
            for j, point in enumerate(ring, 1):
                global_point += 1
                zone_point += 1
                pid = f"{zid}-V{zone_point:02}"
                point_ids.append(pid)
                add("vertices", dict(global_point_no=global_point, zone_no=i, zone_id=zid,
                    zone_point_no=zone_point, point_id=pid, space=z["name"], ring_index=ri, ring_point_no=j,
                    vertex_sequence="approved_trace_order", vertex_role="trace_vertex" if point in originals else "shared_boundary_node",
                    plan_feature="outer_ring" if ri==0 else "hole_ring", crs=CRS) | xy(point), Point(project(point)))
            offset = zone_point - len(ring)
            for j, (a, b) in enumerate(zip(ring, ring[1:] + ring[:1])):
                number = offset + j + 1
                add("zone_wall_segments", dict(segment_id=f"{zid}-B{number:02}", zone_id=zid, segment_no=number,
                    ring_index=ri, boundary_class="traced_zone_boundary", rendering="boundary_review",
                    from_point_id=point_ids[j], to_point_id=point_ids[(j+1)%len(ring)]),
                    LineString([project(a), project(b)]))
        if z["kind"] == "stair":
            add("stair_features", dict(feature_id=f"{zid}-CORE", parent_zone_id=zid, feature_type="stair_core",
                geometry_representation="core_footprint", raster_dependency=False, rendering="outline",
                vertex_count=n) | measures(p), p)

    # These are documented adjacent areas of the marked signs, with no route direction inferred.
    pairs = {
        "EDU-F3-ES-01": ("D1", None), "EDU-F3-ES-02": ("D1", "P1"),
        "EDU-F3-ES-03": ("P1", "B1"), "EDU-F3-ES-04": ("Q1", "S03"),
        "EDU-F3-ES-05": ("WC03", "P1"), "EDU-F3-ES-06": ("Q1", "R1"),
        "EDU-F3-ES-07": ("P2", "R1"), "EDU-F3-ES-08": ("B1", "P2"),
        "EDU-F3-ES-10": ("P2", "H1"), "EDU-F3-ES-11": ("H1", "S02"),
        "EDU-F3-ES-12": ("O2", "U17"), "EDU-F3-ES-13": ("O2", "N2"),
        "EDU-F3-ES-14": ("N1", None), "EDU-F3-ES-15": ("O1", "N2"),
        "EDU-F3-ES-16": ("O1", "U09"), "EDU-F3-ES-17": ("D1", "S01"),
    }
    assert len(sign_list) == len(pairs) == 16
    for s in sign_list:
        sid = s["sign_id"]
        number = int(sid.rsplit("-", 1)[1])
        pair = pairs[sid]
        a, b = (f"EDU-F3-{v}" if v else None for v in pair)
        assert a in zone_polygons and (b is None or b in zone_polygons)
        point = (s["x_px"], s["y_px"])
        g = Point(project(point))
        assert polygon.covers(g)
        add("exit_signs", dict(sign_id=sid, master_id=sid, feature_type="exit_sign",
            zone_id=s["zone_id"], egress=s["description"], adjacent_area_a=a, adjacent_area_b=b,
            rotation_deg=s.get("rotation_deg"), fw_adv_id=s.get("fw_adv_id") or None,
            position_status=s["status"]) | xy(point), g)
        add("egress_links", dict(egress_id=f"EDU-F3-EG-{number:02}", sign_id=sid, master_id=sid,
            from_area=a, to_area=b, description=s["description"], exit_sign_present=True,
            geometry_basis="marked_sign_point_and_trace_adjacency", fw_adv_id=s.get("fw_adv_id") or None,
            route_status="adjacency_only_direction_unverified"), g, sql_geometry=False)

    # Separate access linework. The D1 zone includes the bridge and vestibule.
    door = read_json(ROOT / "source/entrance_door.json")
    a, b = [tuple(value - offset for value, offset in zip(p, SOURCE_OFFSET))
            for p in door["source_pixel_jambs"]]
    threshold = LineString([project(a), project(b)])
    radius = (b[1] - a[1]) / 2
    access_parts = [("threshold", threshold)]
    for hinge, direction, name in ((a, 1, "upper_leaf_swing"), (b, -1, "lower_leaf_swing")):
        # From hinge to open leaf tip, then the drawn swing to the meeting point.
        arc = [(hinge[0] + radius * math.cos(t), hinge[1] + direction * radius * math.sin(t))
               for t in np.linspace(0, math.pi / 2, 13)]
        access_parts.append((name, LineString([project(p) for p in [hinge, *arc]])))
    for part, geometry in access_parts:
        assert zone_polygons[door["zone_id"]].covers(geometry)
        add("door_access", {
            "feature_id": f'{door["access_id"]}-{part}',
            "access_id": door["access_id"], "zone_id": door["zone_id"],
            "egress_id": door["egress_id"], "sign_id": door["sign_id"],
            "feature_type": "double_leaf_door", "part": part,
            "location": door["location"], "swing_toward": door["swing_toward"],
            "opening_m": round(threshold.length, 3) if part == "threshold" else None,
            "review_state": door["review_state"],
        }, geometry)

    for props, geometry in trace_doors(ROOT / "source/room_doors.csv", SOURCE_OFFSET, project, zone_polygons):
        if not polygon.covers(geometry):
            raise ValueError(f"Door access outside traced floorplate: {props['feature_id']}")
        add("door_access", props, geometry)
    final_doors = read_json(ROOT / "source/door_access_final_overrides.json")
    for item in final_doors["features"]:
        plan_points = item["coordinates_plan_px"]
        geometry = LineString([project(tuple(point)) for point in plan_points])
        props = {k: v for k, v in final_doors["access"].items() if k != "feature_id_prefix"} | {
            "feature_id": final_doors["access"]["feature_id_prefix"] + "-" + item["part"],
            "part": item["part"],
            "opening_m": round(geometry.length, 3) if item["part"] == "threshold" else None,
        }
        if not polygon.covers(geometry):
            raise ValueError(f"Final preview door access outside traced floorplate: {props['feature_id']}")
        add("door_access", props, geometry)
    coverage_notes = read_json(ROOT / "source/room_door_coverage_notes.json")
    coverage = list(zone_coverage(original, records["door_access"], coverage_notes))
    csv_out(DATA / "room_door_coverage.csv", list(coverage[0]), coverage)

    stair_vertices = []
    for props, geometry in trace_stairs(ROOT / "source/stair_flight_trace.csv", SOURCE_OFFSET, project):
        if not geometry.is_valid or not zone_polygons[props["parent_zone_id"]].covers(geometry):
            raise ValueError(f"Invalid stair geometry or parent containment: {props['feature_id']}")
        add("stair_flight_detail", props | measures(geometry), geometry)
        coords = layers["stair_flight_detail"][-1]["geometry"]["coordinates"][0][:-1]
        for i, (lon, lat) in enumerate(coords, 1):
            easting, northing = to_grid.transform(lon, lat)
            stair_vertices.append({
                "feature_id": props["feature_id"], "parent_zone_id": props["parent_zone_id"],
                "feature_type": props["feature_type"], "vertex_no": i,
                "longitude": round(lon, 12), "latitude": round(lat, 12),
                "easting_m": round(easting, 4), "northing_m": round(northing, 4),
            })
    csv_out(DATA / "stair_flight_vertices.csv", list(stair_vertices[0]), stair_vertices)

    release = BASE | dict(level_name="Floor 3", address="Joukahaisenkatu 7, Turku, Finland",
        as_of_date=DATE, crs=CRS, metric_crs=METRIC, coordinate_order="longitude, latitude",
        dimensionality="2D", survey_grade=False, review_state=STATE,
        floorplate_count=1, zone_count=len(original), vertex_count=len(records["vertices"]),
        wall_segment_count=len(records["zone_wall_segments"]), lift_car_count=0,
        stair_feature_count=len(records["stair_features"]), exit_sign_count=len(sign_list),
        egress_link_count=len(records["egress_links"]))
    records["dataset_release"] = [release]
    for t, rows in records.items():
        csv_out(DATA / f"{t}.csv", columns[t], rows)
    full = []
    for t in LAYER_ORDER:
        dump(GEO / f"{t}.geojson", collection(layers[t]))
        for item in layers[t]:
            full.append(dict(item, properties=item["properties"] | {"layer": t}))
    dump(GEO / "EduCity_F3_Full.geojson", collection(full))

    footprint = Polygon([(osm_nodes[n]["lon"], osm_nodes[n]["lat"]) for n in osm_way["nodes"]])
    dump(GEO / "control_footprint.geojson", collection([feature(
        {"osm_way_id": osm_way["id"], "source": OSM_URL, "attribution": "© OpenStreetMap contributors"},
        orient(footprint, sign=1.0))]))
    controls = [{"control": i+1, "source_x_px": float(p[0]), "source_y_px": float(p[1]),
                 "osm_node_id": node, "longitude": ll[0], "latitude": ll[1], "easting_m": float(grid[0]),
                 "northing_m": float(grid[1]), "fit_residual_m": round(float(error), 5)}
                for i, (p, node, ll, grid, error) in enumerate(zip(plan_control, control_ids, control_ll, control_grid, errors))]
    csv_out(DATA / "georeference_controls.csv", list(controls[0]), controls)
    fit = dict(status=STATE, survey_grade=False, registration="affine to four main-building OSM footprint corners",
               source=OSM_URL, source_version=osm_way["version"], source_timestamp=osm_way["timestamp"],
               source_attribution="© OpenStreetMap contributors", projected_crs=METRIC, output_crs=CRS,
               coefficients=affine.tolist(), control_fit_rmse_m=float(np.sqrt(np.mean(errors**2))),
               independent_survey_check=False, controls=controls, main_envelope_grid_metres={
                   "width": float(np.linalg.norm(control_grid[1]-control_grid[0])),
                   "length": float(np.linalg.norm(control_grid[3]-control_grid[0]))},
               note="F3 follows a footprint-based display registration. Footprint outlines and F3 walls may differ. Fit residual is internal and does not measure field accuracy.")
    dump(DATA / "georeference.json", fit)
    dump(DATA / "canonical_snapshot.json", dict(release=release, georeference=fit, features=layers))
    qa = [
        ("Zone polygons", 52, len(original)), ("Exit sign points", 16, len(sign_list)),
        ("Zone overlap above 1e-6 m²", 0, int(max_overlap >= 1e-6)),
        ("Zone area outside traced floorplate above 1e-6 m²", 0, int(max_escape >= 1e-6)),
        ("Source trace vertices before shared-boundary noding", 275, sum(len(r) for z in original for r in z["rings"])),
        ("Survey-grade status", False, release["survey_grade"]),
    ]
    qa_rows = [dict(release_id=RELEASE, check_no=i, check_name=n, expected=e, observed=o,
                    status="PASS" if e==o else "FAIL") for i,(n,e,o) in enumerate(qa,1)]
    assert all(r["status"]=="PASS" for r in qa_rows)
    csv_out(DATA / "qa_results.csv", columns["qa_results"], qa_rows)
    dump(ROOT / "qa/geometry_validation.json", dict(checks=qa_rows, max_zone_overlap_m2=max_overlap,
         max_zone_escape_m2=max_escape, trace_vertices=275, gis_vertices=global_point,
         independent_survey_validation=False, source_outline_fit_rmse_m=fit["control_fit_rmse_m"]))

    write_gpkg(records, columns, grid_layers)
    write_sql(records, columns)
    write_kml(layers)
    print(json.dumps(dict(counts={k:len(v) for k,v in records.items()}, rmse_m=fit["control_fit_rmse_m"],
                          area_m2=polygon.area, footprint_version=osm_way["version"])))


def write_gpkg(records, columns, grid_layers):
    target = ROOT / "EduCity_F3.gpkg"
    target.unlink(missing_ok=True)
    for table in LAYER_ORDER:
        rows = records[table]
        if not rows:
            continue
        fields = [c for c in columns[table] if c not in ("geom", "swing_geom")]
        values = []
        for name in fields:
            vals = [r.get(name) for r in rows]
            nums = [v for v in vals if v is not None]
            if nums and all(isinstance(v, (int, float, bool)) for v in nums):
                dtype = float if len(nums)!=len(vals) or any(isinstance(v,float) for v in nums) else int
                values.append(np.asarray(vals, dtype=dtype))
            else:
                values.append(np.asarray(vals, dtype=object))
        write_vector(target, np.asarray([g.wkb for g in grid_layers[table]], dtype=object),
                     values, fields, layer=table, driver="GPKG", geometry_type=KINDS[table],
                     crs=METRIC, append=target.exists())


def write_sql(records, columns):
    order = ("dataset_release", *LAYER_ORDER)
    body = [f"DELETE FROM educity_f3.{t} WHERE release_id = '{RELEASE}';" for t in reversed(order)]
    body.insert(0, "SELECT pg_advisory_xact_lock(hashtext('educity_f3'));")
    for t in order:
        rows = records[t]
        if not rows:
            continue
        fields = columns[t]
        row_sql = ["(" + ", ".join(literal(row.get(c), c) for c in fields) + ")" for row in rows]
        body.append(f"INSERT INTO educity_f3.{t} ({', '.join(fields)}) VALUES\n" + ",\n".join(row_sql) + ";")
    (SQL / "01_load.sql").write_text("\\set ON_ERROR_STOP on\nBEGIN;\n" + "\n".join(body) + "\nCOMMIT;\n", encoding="utf-8")


def write_kml(layers):
    def coords(points):
        return " ".join(f"{p[0]:.10f},{p[1]:.10f}" for p in points)

    root = ET.Element("kml", xmlns="http://www.opengis.net/kml/2.2")
    doc = ET.SubElement(root, "Document")
    ET.SubElement(doc, "name").text = "EduCity F3 • draft footprint registration"
    for key in ("floorplate", "zones", "exit_signs", "stair_features", "door_access", "stair_flight_detail"):
        folder = ET.SubElement(doc, "Folder")
        ET.SubElement(folder, "name").text = key
        for item in layers[key]:
            p = item["properties"]
            g = item["geometry"]
            place = ET.SubElement(folder, "Placemark")
            ET.SubElement(place, "name").text = p["feature_id"] if key in {"door_access", "stair_flight_detail"} else p.get("sign_id") or p.get("zone_id") or p["feature_id"]
            ET.SubElement(place, "description").text = p.get("space") or p.get("egress") or p.get("part") or p["feature_type"]
            k = ET.SubElement(place, g["type"])
            if g["type"] == "Point":
                ET.SubElement(k, "coordinates").text = coords([g["coordinates"]])
            elif g["type"] == "LineString":
                ET.SubElement(k, "coordinates").text = coords(g["coordinates"])
            else:
                for i, ring in enumerate(g["coordinates"]):
                    boundary = ET.SubElement(k, "outerBoundaryIs" if i==0 else "innerBoundaryIs")
                    ET.SubElement(ET.SubElement(boundary,"LinearRing"),"coordinates").text = coords(ring)
    ET.ElementTree(root).write(ROOT / "EduCity_F3.kml", encoding="utf-8", xml_declaration=True)


if __name__ == "__main__":
    main()
