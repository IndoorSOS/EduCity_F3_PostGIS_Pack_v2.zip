"""Emit a typed workbook data specification to stdout."""
import csv
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
GEO = json.loads((DATA / "georeference.json").read_text())
PG = json.loads((ROOT / "qa/postgis_validation.json").read_text())
RELEASE = PG["release"]
TABLES = [
    ("Floorplate", "floorplate", "Traced boundary and cropped ICT-City connection"),
    ("Zones", "zones", "52 attributed polygons including stairs and lift shafts"),
    ("Vertices", "vertices", "Ring and sequence register for 340 geographic vertices"),
    ("Floorplate Vertices", "floorplate_vertices", "30 ordered floorplate vertices"),
    ("Wall Segments", "zone_wall_segments", "Zone boundaries. Rendering distinguishes line types."),
    ("Lift Cars", "lift_cars", "No traced cars. Four shafts are in Zones."),
    ("Stair Features", "stair_features", "Four traced core footprints"),
    ("Stair Flight Detail", "stair_flight_detail", "Geocoded bands, visible treads, landings and terrace review candidates"),
    ("Stair Vertices", "stair_flight_vertices", "WGS 84 longitude and latitude and EPSG:3877 coordinates"),
    ("Exit Signs", "exit_signs", "16 user-marked positions synchronized to the supplied preview"),
    ("Egress Links", "egress_links", "Sign adjacency, with travel direction unverified"),
    ("Door Access", "door_access", "66 access thresholds with traced swings where visible"),
    ("Room Door Coverage", "room_door_coverage", "Door disposition for all 52 frozen zones"),
    ("QA", "qa_results", "Source register and PostGIS validation results for this release"),
]
NUMERIC = re.compile(r"(_no|_count|_index|_number|_m|_m2|_x|_y|_deg|^longitude|^latitude)$")


def matrix(table):
    with (DATA / f"{table}.csv").open(newline="", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    headers = rows.pop(0)
    if table in ("exit_signs", "egress_links"):
        ix = headers.index("fw_adv_id")
        to = headers.index("sign_id") + 1
        for row in [headers, *rows]:
            row.insert(to, row.pop(ix))
    data = []
    for row in rows:
        data.append([None if not v else v == "True" if v in ("True", "False")
            else float(v) if NUMERIC.search(h) else v for h, v in zip(headers, row)])
    return [["FW Adv id" if h == "fw_adv_id" else h for h in headers], *data]


workbook = [
    {"name": "Summary", "subtitle": "Third-floor developer register · 7 City Road F7 structure",
     "rows": [["Item", "Value"], ["Release", RELEASE], ["Site", "EDUCITY-TURKU"],
              ["Level", "F3"], ["Address", "Joukahaisenkatu 7, Turku, Finland"],
              ["Display registration", "Draft footprint registration"],
              ["PostGIS CRS", "EPSG:4326 longitude, latitude"], ["Metric CRS", "EPSG:3877"],
              ["Zones", 52], ["Zone vertices", 340], ["Boundary segments", 340],
              ["Floorplate vertices", 30], ["Stair cores", 4], ["Visible stair runs", 14], ["Visible tread polygons", 83], ["Lift shafts", 4],
              ["Corrected exit signs", 16], ["Sign adjacency records", 16],
              ["Traced door and opening locations", 66],
              ["PostGIS QA checks", len(PG["checks"])], ["Standalone loads", PG["standalone_load_runs"]],
              ["Survey grade", False], ["Mapped control", GEO["source"]]]}
]
for name, table, subtitle in TABLES:
    rows = matrix(table)
    if table == "qa_results":
        for q in PG["checks"]:
            rows.append([RELEASE, len(rows), "PostGIS · "+q["check_name"],
                         q["expected"], q["observed"], "PASS" if q["pass"] else "FAIL"])
    workbook.append({"name": name, "subtitle": subtitle, "rows": rows})
workbook.append({"name": "Read Me", "subtitle": "Coordinate model, provenance and field status",
    "rows": [["Topic", "Detail"],
             ["Registration", "Four main rectangle corners fitted in EPSG:3877."],
             ["Horizontal accuracy", "Draft mapped footprint fit. Survey accuracy has not been established."],
             ["Geometry", "PostGIS and GeoJSON use EPSG:4326. GeoPackage uses EPSG:3877."],
             ["Pixel columns", "Retained as source trace references. Geometry is geographic."],
             ["Exit signs", "16 positions synchronized to the supplied Nov 5 preview."],
             ["FW Adv id", "Assigned where supplied: ES-06, ES-07, ES-10, and ES-11."],
             ["Egress adjacency", "From and to columns store adjacency. Travel direction is unverified."],
             ["Door access", "Door and lift thresholds plus visible leaf swings. Widths are estimated from the drawing."],
             ["Stairs and lifts", "Stair core, flight, tread and landing polygons are available. Lift cars remain untraced."],
             ["Vertical measurements", "Floor elevation is unverified and left blank."],
             ["Footprint attribution", "© OpenStreetMap contributors. Way 731925812, version 19."],
             ["Loading", "See README.md and sql/99_standalone_full_load.sql."]]})
print(json.dumps(workbook,ensure_ascii=False))
