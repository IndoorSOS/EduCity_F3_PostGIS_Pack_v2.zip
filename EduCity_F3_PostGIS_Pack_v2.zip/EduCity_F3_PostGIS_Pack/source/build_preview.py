"""Draw the offline GIS preview from the released WGS84 layers."""
import base64
import csv
import html
import json
import math
import re
from pathlib import Path
from collections import defaultdict

from pyproj import Geod, Transformer
from shapely.geometry import shape
from shapely.ops import unary_union

ROOT = Path(__file__).resolve().parents[1]
GRID = Transformer.from_crs(4326, 3877, always_xy=True)
GEOD = Geod(ellps="WGS84")


def read(layer):
    return json.loads((ROOT / f"geojson/{layer}.geojson").read_text())["features"]


def ring_points(feature):
    return [p for ring in feature["geometry"]["coordinates"] for p in ring]


floor, = read("floorplate")
outline, = read("control_footprint")
zones = read("zones")
signs = read("exit_signs")
door_access = read("door_access")
stair_detail = read("stair_flight_detail")
with (ROOT / "data/exit_sign_display.csv").open(newline="", encoding="utf-8") as file:
    sign_display = {r["sign_id"]: r for r in csv.DictReader(file)}
sign_icon = base64.b64encode((ROOT / "assets/exit-sign-fixture.png").read_bytes()).decode("ascii")
west, south, east, north = unary_union([
    shape(floor["geometry"]), shape(outline["geometry"])
]).bounds
centre = (west + east) / 2, (south + north) / 2
grid_points = [GRID.transform(*p) for p in ring_points(floor) + ring_points(outline)]
e0 = min(x for x, y in grid_points)
n0 = max(y for x, y in grid_points)
s = min(655 / (max(x for x, y in grid_points) - e0), 630 / (n0 - min(y for x, y in grid_points)))


def xy(lonlat):
    x, y = GRID.transform(*lonlat)
    return 22 + s * (x - e0), 42 + s * (n0 - y)


def polygon(feature):
    return " ".join(
        "M" + " L".join(f"{x:.3f},{y:.3f}" for x, y in map(xy, ring)) + "Z"
        for ring in feature["geometry"]["coordinates"]
    )


def label(value):
    return html.escape(value, quote=True)


parts = [f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 716" role="img" aria-labelledby="map-title map-desc">
<title id="map-title">EduCity Floor 3 geographic plan</title>
<desc id="map-desc">{len(zones)} colored polygons and {len(signs)} exit sign positions aligned to the mapped EduCity footprint, with {sum(f["properties"]["part"] == "threshold" for f in door_access)} door and opening locations and geocoded stair flights.</desc>
<rect width="700" height="716" fill="#f2f6f7"/>
<defs><image id="fixture-icon" x="-8.5" y="-4.72" width="17" height="9.44" href="data:image/png;base64,{sign_icon}"/></defs>
<path id="control" d="{polygon(outline)}" fill="none" stroke="#767d89" stroke-dasharray="5 4" stroke-width="1.3"/>
<path d="{polygon(floor)}" fill="#e7edf0" stroke="#172e41" stroke-width="1.8"/>
<g id="zone-layer" fill-rule="evenodd" stroke="#465a66" stroke-width=".65">''']
for f in zones:
    p = f["properties"]
    description = label(f'{p["zone_id"]} · {p["space"]} · {p["area_m2"]:,.1f} m²')
    parts.append(f'<path tabindex="0" d="{polygon(f)}" fill="{p["display_color"]}" data-detail="{description}"><title>{description}</title></path>')
parts.append('</g><g id="stair-layer">')
stair_groups = defaultdict(list)
for f in stair_detail:
    p = f["properties"]
    key = p["feature_id"] if p["feature_type"] == "stair_candidate" else p["parent_zone_id"]
    stair_groups[key].append(f)
stair_options = []
stair_extents = {}
styles = {
    "stair_landing": 'fill="#d7e4e8" stroke="#426271" stroke-width=".45"',
    "stair_flight": 'fill="#7ebec7" stroke="#16546b" stroke-width="1.2"',
    "stair_tread": 'fill="none" stroke="#20506b" stroke-width=".45"',
    "stair_candidate": 'fill="#f7dc8c" stroke="#8a5c07" stroke-width="1" stroke-dasharray="2 1"',
}
for key, group in stair_groups.items():
    xx, yy = zip(*(xy(point) for f in group for point in ring_points(f)))
    span = max(max(xx)-min(xx), max(yy)-min(yy)) + 10
    ext = f"{(max(xx)+min(xx)-span)/2:.3f} {(max(yy)+min(yy)-span)/2:.3f} {span:.3f} {span:.3f}"
    stair_extents[key] = ext
    candidate = group[0]["properties"]["feature_type"] == "stair_candidate"
    name = ("R1 terrace candidate · " + group[0]["properties"]["plan_position"]) if candidate else key.removeprefix("EDU-F3-")
    stair_options.append(f'<option value="{key}" data-view="{ext}">{label(name)}</option>')
    parts.append(f'<g id="{key}" tabindex="0" role="button" data-stair="{key}" data-detail="{label(name)}"><title>{label(name)}</title>')
    order = {"stair_landing": 0, "stair_flight": 1, "stair_tread": 2, "stair_candidate": 3}
    for f in sorted(group, key=lambda f: order[f["properties"]["feature_type"]]):
        q = f["properties"]
        title = label(f'{q["feature_id"]} · {q["source_visibility"].replace("_", " ")}')
        parts.append(f'<path d="{polygon(f)}" {styles[q["feature_type"]]}><title>{title}</title></path>')
    parts.append('</g>')
parts.append('</g><g id="zone-labels" pointer-events="none" text-anchor="middle" dominant-baseline="middle" font-family="Arial,sans-serif" font-size="9" font-weight="700" fill="#172e41" stroke="#fff" stroke-width="2.2" paint-order="stroke">')
for f in zones:
    p = f["properties"]
    point = shape(f["geometry"]).representative_point()
    x, y = xy((point.x, point.y))
    if p["zone_id"] == "EDU-F3-D1":
        x, y = xy((22.296790, 60.448653))
    parts.append(f'<text x="{x:.2f}" y="{y:.2f}">{label(p["zone_id"].removeprefix("EDU-F3-"))}</text>')
parts.append('</g><g id="door-layer" fill="none" stroke-linejoin="round" stroke-linecap="round">')
door_groups = defaultdict(list)
for f in door_access:
    door_groups[f["properties"]["access_id"]].append(f)
door_extents = {}
options = []
for access_id, features in door_groups.items():
    p = features[0]["properties"]
    opening = next(f for f in features if f["properties"]["part"] == "threshold")
    xx, yy = zip(*(xy(q) for q in opening["geometry"]["coordinates"]))
    cx, cy = sum(xx)/2, sum(yy)/2
    door_extents[access_id] = f"{cx-19:.3f} {cy-15:.3f} 38 30"
    description = label(f'{access_id} · {p["location"]} · {p["feature_type"].replace("_", " ")}')
    sign_id = p.get("sign_id") or ""
    options.append(f'<option value="{access_id}" data-view="{door_extents[access_id]}" data-sign="{sign_id}">{description}</option>')
    parts.append(f'<g id="{access_id}" tabindex="0" data-door="{access_id}" data-detail="{description}"><title>{description}</title>')
    for f in features:
        a = f["properties"]
        path = "M" + " L".join(f"{x:.3f},{y:.3f}" for x, y in map(xy, f["geometry"]["coordinates"]))
        color = {"opening_only":"#a16100", "lift_entrance":"#51409e"}.get(a["feature_type"], "#80371f")
        dashed = ' stroke-dasharray="2 1"' if a["feature_type"] == "opening_only" else ""
        weight = 1.45 if a["part"] == "threshold" else .8
        parts.append(f'<path d="{path}" stroke="{color}" stroke-width="{weight}"{dashed}/>')
    parts.append('</g>')
parts.append('</g><g id="sign-layer">')
for f in signs:
    p = f["properties"]
    sid = p["sign_id"]
    orient = sign_display[sid]
    x, y = xy(f["geometry"]["coordinates"])
    description = label(f'{sid} · {p["egress"]}')
    fw_adv_id = p.get("fw_adv_id") or ""
    fw_attribute = f' data-fw-adv-id="{label(fw_adv_id)}"' if fw_adv_id else ""
    parts.append(f'<g id="{sid}" tabindex="0" role="button" aria-label="{description}" '
                 f'transform="translate({x:.3f} {y:.3f}) rotate({orient["svg_rotation_deg"]})" '
                 f'{fw_attribute} data-door="{orient["access_id"]}" data-detail="{description}"><title>{description}</title>'
                 '<rect x="-8.8" y="-5.0" width="17.6" height="10" rx=".8" fill="#fff" fill-opacity=".82"/>'
                 '<use href="#fixture-icon" pointer-events="none"/></g>')
parts.append('</g><g font-family="Arial,sans-serif" text-anchor="middle" font-weight="700">')
cx, cy = 80, 82
parts.append(f'<circle cx="{cx}" cy="{cy}" r="47" fill="white" stroke="#c3d0d8"/>')
xc, yc = xy(centre)
for degrees, name in enumerate(("N", "NE", "E", "SE", "S", "SW", "W", "NW")):
    lon, lat, _ = GEOD.fwd(*centre, degrees * 45, 30)
    xx, yy = xy((lon, lat))
    length = math.hypot(xx - xc, yy - yc)
    dx, dy = (xx - xc) / length, (yy - yc) / length
    color = "#a82144" if name == "N" else "#31526b"
    r = 29 if name == "N" else 23
    parts.append(f'<line x1="{cx}" y1="{cy}" x2="{cx+r*dx:.2f}" y2="{cy+r*dy:.2f}" stroke="{color}" stroke-width="{2 if name=="N" else 1}"/>')
    if name == "N":
        apex = f"{cx+r*dx:.2f},{cy+r*dy:.2f}"
        a = f"{cx+(r-8)*dx+3.5*dy:.2f},{cy+(r-8)*dy-3.5*dx:.2f}"
        b = f"{cx+(r-8)*dx-3.5*dy:.2f},{cy+(r-8)*dy+3.5*dx:.2f}"
        parts.append(f'<polygon points="{apex} {a} {b}" fill="{color}"/>')
    parts.append(f'<text x="{cx+37*dx:.2f}" y="{cy+37*dy+3:.2f}" fill="{color}" font-size="{10 if name=="N" else 8}">{name}</text>')
parts.append(f'''<circle cx="{cx}" cy="{cy}" r="3" fill="#31526b"/>
<text x="{cx}" y="{cy+65}" font-size="10" fill="#31526b">True bearings</text>
</g>
<g transform="translate(30 675)" font-family="Arial,sans-serif" font-size="11" fill="#172e41">
<path d="M0 -4V4H{10*s:.2f}V-4 M{5*s:.2f} 0V4" fill="none" stroke="#172e41" stroke-width="1.5"/>
<text x="0" y="18">0</text><text x="{10*s:.2f}" y="18" text-anchor="end">10 m</text></g>
</svg>''')
svg = "\n".join(parts)
(ROOT / "assets/EduCity_F3_Map.svg").write_text(svg+"\n", encoding="utf-8")
detail = f'''<svg xmlns="http://www.w3.org/2000/svg" id="door-inset" viewBox="{door_extents["EDU-F3-DA-01"]}" role="img" aria-label="Magnified trace of the selected door">
<use href="#zone-layer"/>
<use href="#EDU-F3-DA-01" id="inset-door"/>
<use href="#EDU-F3-ES-01" id="inset-sign"/>
</svg>'''
stair_inset = f'''<svg xmlns="http://www.w3.org/2000/svg" id="stair-inset" viewBox="{stair_extents["EDU-F3-S01"]}" role="img" aria-label="Geocoded stair flight detail">
<use href="#zone-layer"/>
<use href="#EDU-F3-S01" id="inset-stair"/>
</svg>'''
page = '''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>EduCity F3 | PostGIS release preview</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#edf2f5;color:#172e41;font:16px system-ui,sans-serif}
main{max-width:1160px;margin:auto;padding:28px}header{border-bottom:1px solid #ccd8df;padding:0 0 18px}
.kicker{color:#286763;letter-spacing:.11em;text-transform:uppercase;font-weight:700;font-size:.75rem}h1{margin:.25em 0;font-size:2.4rem}
header p{margin:.35em 0}section{display:grid;grid-template-columns:minmax(0,2.4fr) minmax(240px,1fr);gap:20px;margin-top:20px;align-items:start}
.map,aside{background:white;border:1px solid #cddbe1;border-radius:10px;overflow:hidden}svg{display:block;width:100%;height:auto}
aside{padding:20px}aside h2{font-size:1.06rem;margin:0 0 12px}aside p{line-height:1.45}aside label{display:block;margin:.6em 0}
.door-detail{margin:12px 0;border:1px solid #cddbe1;border-radius:6px;overflow:hidden}
#detail{background:#edf5f4;border-radius:6px;padding:10px;min-height:62px;font-size:.93rem;overflow-wrap:anywhere}
a{color:#075c73}button,input,svg [tabindex]{cursor:pointer}
svg [tabindex]:hover,svg [tabindex]:focus{stroke:#a82144;stroke-width:2;outline:none}
@media(max-width:750px){section{grid-template-columns:1fr}main{padding:16px}}
</style></head><body><main><header>
<div class="kicker">Turku, Finland · Floor 3 · PostGIS release</div>
<h1>EduCity</h1><p>Joukahaisenkatu 7 · Draft footprint registration</p></header>
<section><div class="map">__SVG__</div><aside><h2>Map layers</h2>
<label><input type="checkbox" data-layer="sign-layer" checked> Exit signs ({len(signs)})</label>
<label><input type="checkbox" data-layer="door-layer" checked> Doors and openings ({sum(f["properties"]["part"] == "threshold" for f in door_access)})</label>
<label><input type="checkbox" data-layer="stair-layer" checked> Stair flights and treads</label>
<label><input type="checkbox" data-layer="zone-labels" checked> Zone labels (52)</label>
<label><input type="checkbox" data-layer="control" checked> Mapped footprint outline</label>
<p id="detail" aria-live="polite">Select a zone, stair core, door, or exit sign.</p>
<h2>Door detail</h2>
<label for="door-select">Door or opening</label>
<select id="door-select" style="width:100%">__OPTIONS__</select>
<div class="door-detail">__DETAIL__</div>
<p>Brown lines show drawn doors and their swings. Dashed amber lines mark openings for review. Purple lines mark lift entrances.</p>
<h2>Stair flight detail</h2>
<label for="stair-select">Core or terrace review area</label>
<select id="stair-select" style="width:100%">__STAIR_OPTIONS__</select>
<div class="door-detail">__STAIR_INSET__</div>
<p>Blue bands show the visible flights and tread outlines. Pale areas show interpreted landings. Dashed amber outlines mark terrace candidates. The drawing leaves vertical direction and floor connections unverified.</p>
<h2>Coordinate reference</h2><p>Map and scale use EPSG:3877. The compass indicates true bearings. Exported PostGIS geometry is EPSG:4326.</p>
<p>Each fixture is aligned to its traced doorway threshold. The orientation shows the doorway alignment. Travel direction and installed fixture facing are unverified.</p>
<p><a href="assets/EduCity_F3_Satellite_Review.html">Open the visual satellite reference</a></p>
<p><a href="https://www.openstreetmap.org/way/731925812">© OpenStreetMap contributors</a></p></aside></section>
</main><script>
for(const checkbox of document.querySelectorAll('input[data-layer]')) {
  checkbox.addEventListener('change',()=> {
    document.getElementById(checkbox.dataset.layer).style.display=checkbox.checked?'':'none';
  });
}
const doorSelect=document.getElementById('door-select');
function inspectDoor(id) {
  doorSelect.value=id;
  const selected=doorSelect.selectedOptions[0];
  document.getElementById('door-inset').setAttribute('viewBox',selected.dataset.view);
  document.getElementById('inset-door').setAttribute('href','#'+id);
  const sign=document.getElementById('inset-sign');
  if(selected.dataset.sign) sign.setAttribute('href','#'+selected.dataset.sign);
  else sign.removeAttribute('href');
}
doorSelect.addEventListener('change',()=>inspectDoor(doorSelect.value));
const stairSelect=document.getElementById('stair-select');
function inspectStair(id) {
  stairSelect.value=id;
  document.getElementById('stair-inset').setAttribute('viewBox',stairSelect.selectedOptions[0].dataset.view);
  document.getElementById('inset-stair').setAttribute('href','#'+id);
}
stairSelect.addEventListener('change',()=>inspectStair(stairSelect.value));
for(const feature of document.querySelectorAll('[data-detail]')) {
  const show=()=> {
    document.getElementById('detail').textContent=feature.dataset.detail;
    if(feature.dataset.door) inspectDoor(feature.dataset.door);
    if(feature.dataset.stair) inspectStair(feature.dataset.stair);
  };
  feature.addEventListener('click',show);
  feature.addEventListener('focus',show);
  if(feature.getAttribute('role')==='button') {
    feature.addEventListener('keydown',event=>{if(event.key==='Enter' || event.key===' ') {event.preventDefault();show();}});
  }
}
</script></body></html>'''
preview = page.replace("__SVG__", svg).replace("__DETAIL__", detail).replace("__OPTIONS__", "\n".join(options)).replace("__STAIR_OPTIONS__", "\n".join(stair_options)).replace("__STAIR_INSET__", stair_inset)
final_preview = ROOT / "source/final_preview.html"
if final_preview.exists():
    preview = final_preview.read_text(encoding="utf-8")
    inline_svg = re.search(r'<svg\b.*?</svg>', preview, re.S)
    if not inline_svg:
        raise ValueError("The frozen final preview has no inline SVG")
    (ROOT / "assets/EduCity_F3_Map.svg").write_text(inline_svg.group() + "\n", encoding="utf-8")
(ROOT / "EduCity_F3_PostGIS_Preview.html").write_text(preview, encoding="utf-8")
