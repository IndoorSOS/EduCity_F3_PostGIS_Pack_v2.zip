# EduCity F3 PostGIS Pack

**EduCity, third floor** · Joukahaisenkatu 7, Turku, Finland  
Release `educity-f3-20261105-postgis-v2` · Site key `EDUCITY-TURKU`

This revision is synchronized to the supplied 2026-11-05 preview. It updates sign positions and associations, removes ES-09, applies the WC03 double-swing egress geometry, and refreshes the current door-access records. The traced floorplate, zones, and stair-detail layers are retained.

This developer handoff follows the validated 7 City Road F7 package’s table, CSV, GeoJSON, workbook, and SQL layout. It contains the color-up floorplate and the 16 exit sign positions in the supplied preview. The source-image coordinates are kept in the registers for traceability.

## Load and display

Extract the full ZIP. Run from the extracted pack directory with a PostgreSQL database connection. The database must have PostGIS installed or allow the loader role to install the extension.

```bash
psql -X "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/99_standalone_full_load.sql
```

The standalone loader creates the `educity_f3` schema, loads this release, creates the views, and checks the data in one transaction. Re-running it refreshes this release. For staged loading, use `00_schema.sql`, `01_load.sql`, `02_validate.sql`, and `03_views.sql` in sequence.

In a PostGIS client such as QGIS, add `educity_f3.floorplate`, `educity_f3.zones`, and `educity_f3.exit_signs`. Use `zone_id` for zone labels and `display_color` for fills. Use the 4326 `geom` column. Filter by release ID if the schema contains multiple releases. Add `v_egress_signs` when you want the adjacency register joined to the sign points. Its geometry is the sign location. Add `educity_f3.v_room_door_access` to display all threshold and swing linework. Filter on `part = 'threshold'` for one record per access, or on `zone_id` and `adjacent_zone_id` for a room. The D1-only view remains available as `educity_f3.v_entrance_egress`. Add `educity_f3.v_stair_flights` for the 14 flight bands or `educity_f3.stair_flight_detail` for the complete stair detail. The equivalent files for offline viewing are `EduCity_F3.gpkg` and `EduCity_F3_PostGIS_Preview.html`.

```sql
SELECT zone_id, space, display_color, area_m2, geom
FROM educity_f3.v_zone_summary
WHERE release_id = 'educity-f3-20261105-postgis-v2';

SELECT check_name, expected, observed, pass
FROM educity_f3.v_release_qa
WHERE release_id = 'educity-f3-20261105-postgis-v2'
ORDER BY check_name;
```

## Contents

| Layer or register | Features | PostGIS representation |
|---|---:|---|
| Floorplate | 1 | Polygon |
| Floorplate vertices | 30 | Point |
| Zones | 52 | Polygon |
| Zone vertices | 340 | Point |
| Zone wall segments | 340 | LineString |
| Stair cores | 4 | Polygon |
| Visible stair runs | 14 | Polygon |
| Visible stair treads | 83 | Polygon |
| Interpreted landing areas | 14 | Polygon |
| Terrace review candidates | 2 | Polygon |
| Lift shafts | 4 | Polygon in `zones` and `v_lift_shafts` |
| Corrected exit signs | 16 | Point |
| Egress adjacency | 16 | Register joined to sign points by `v_egress_signs` |
| Room door and opening access | 66 thresholds, 70 swing lines | LineString parts in `door_access` |
| Lift cars and single doors | 0 | Empty compatibility tables |

The 340 zone vertices comprise 275 traced vertices and 65 existing junctions inserted along shared edges before reprojection. The boundary segment register includes review subdivisions. Use it as zone linework. Door linework follows the source drawing and the existing georeference. Each access has a threshold and zero, one, or two leaf swing lines. The 66 locations comprise 40 single-leaf doors, 15 double-leaf doors, seven opening-only traces requiring review, and four lift entrance spans. All 16 current sign positions are linked to their corresponding access records. These associations describe plan locations. Travel directions and field conditions remain unverified.

`data/room_door_coverage.csv` gives one disposition per frozen zone. Six polygons have no distinct doorway traced. N9 shares its drawn enclosure with N8, whose north door is indexed under N8. C1–C4 and RF1 have no readable discrete door symbol. Where a wall gap or parallel strokes are visible but the leaf is uncertain, only the opening is traced. Lift entries are traced as spans without lift-car geometry. Door widths are approximate drawing-derived values. The `image_left`, `image_right`, `image_up`, and `image_down` swing fields refer to the architectural drawing axes. Source jamb picks and swing directions are in `source/room_doors.csv`.

| File or directory | Use |
|---|---|
| `sql/` | Schema, typed geographic load, checks, display views, and standalone loader |
| `data/` | F7-compatible CSV registers, georeference controls, and canonical snapshot |
| `geojson/` | Individual WGS84 layers and one combined FeatureCollection |
| `EduCity_F3.gpkg` | Ten populated layers in the local metric CRS |
| `EduCity_F3.kml` | Floorplate, zones, sign points, stair cores, stair detail, and door linework for globe viewers |
| `EduCity_F3_Vertices_and_Features.xlsx` | F7 register workbook with `FW Adv id` columns and door coverage, stair flight, and stair vertex registers |
| `EduCity_F3_PostGIS_Preview.html` | Offline GIS preview with zone fills, sign markers, selectable door, sign, and stair detail insets, compass, and scale |
| `assets/` | Source floor plan, corrected sign reference, map render, and earlier satellite review |
| `source/`, `qa/` | Build inputs, runnable code, and recorded validation |

## Stair flight detail

| Core | Visible flight bands | Visible tread polygons | Interpreted landings |
|---|---:|---:|---:|
| S01 | 3 | 21 | 3 |
| S02 | 3 | 21 | 3 |
| S03 | 4 | 21 | 4 |
| S04 | 4 | 20 | 4 |

The tread polygons are the spaces between consecutive tread lines visible in the architectural drawing. A flight band covers its visible tread polygons, so those two layers intentionally overlap. Some bands are cut short in the drawing. The `tread_index` numbers follow increasing source-image coordinates on the run axis. Positions such as `PLAN-T` are sheet positions. Landing footprints are interpreted from the clear areas adjacent to the runs. Two plausible R1 terrace features are supplied as draft review outlines, without tread counts. The long striped edge along the larger terrace platform is visually ambiguous and was excluded.

`geojson/stair_flight_detail.geojson` and the PostGIS polygon layer use WGS 84 longitude and latitude. `data/stair_flight_vertices.csv` and the workbook's **Stair Vertices** sheet provide both WGS 84 and EPSG:3877 coordinates for all polygon corners. `source/stair_flight_trace.csv` preserves the measured drawing picks. This is 2D drawing-derived geometry. Floor connections, UP/DOWN directions, elevations and the full built tread counts remain unverified.

## Exit-sign display alignment

The preview fixture artwork is in `assets/exit-sign-fixture.png`. The geographic preview and satellite review each embed the artwork and apply per-sign rotations. Select a sign on the geographic preview to open its linked doorway detail. The display register in `data/exit_sign_display.csv` lists each sign and access ID, the SVG and drawing rotation, and the true-north axes along and across the doorway. Those axes are undirected. The icon rotation describes fixture alignment for the map. The travel direction and installed fixture facing are unverified.

The sign display register follows the supplied preview. The four assigned FW Adv IDs are HLP006400990000011 (ES-06), HLP006500990000011 (ES-07), HLP006600990000011 (ES-10), and HLP006700990000011 (ES-11). Display orientation follows the approved preview; field travel direction remains unverified.

## Registration and field status

PostGIS geometry and GeoJSON use WGS 84, EPSG:4326, in longitude and latitude order. The GeoPackage and measurements use ETRS89 / GK23FIN, EPSG:3877, in metres. The compass shows true bearings. The plan is two-dimensional. Floor elevation is blank.

The four main rectangular corners of the floor drawing were matched to the corresponding corners of OpenStreetMap way 731925812, version 19, and fitted by affine transformation in EPSG:3877. The exact corner pairs, fit coefficients, and residuals are in `data/georeference.json`. The small residual measures fit to those mapped controls. Independent survey accuracy has not been established. The release records `survey_grade=false`. The traced floorplate includes the portion of the ICT-City link visible on the plan. The full OSM outline is a separate control reference. The earlier satellite review retains the visual roof-cover overlay.

Sign points preserve the corrected marked locations and the local `EDU-F3-ES-xx` IDs. Four `FW Adv id` values are assigned as listed in the exit-sign register. Sign rotation follows the supplied preview. Egress records describe sign adjacency. Their `from_area` and `to_area` columns preserve the F7 layout. Travel direction, route connectivity, and floor-to-floor pairings are unverified. The three sign records with an unknown second adjacent area have a null `to_area`.

Footprint source © OpenStreetMap contributors. [Mapped footprint](https://www.openstreetmap.org/way/731925812) · [Data terms](https://www.openstreetmap.org/copyright)

## Rebuild and verify

Run the GIS builder with Python 3.11+ and the packages in `source/requirements.txt`. The source trace and footprint snapshot are bundled. Rebuilding the core GIS files requires no live map service.

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r source/requirements.txt
python source/build_gis.py
python source/build_standalone.py
python source/build_sign_display.py
python source/build_preview.py
python source/verify_exports.py
```

Use `sha256sum -c SHA256SUMS.txt` to check the delivered files **before** rebuilding. Generated container files can include fresh metadata on rebuild.

The included PostGIS loader and validation SQL are updated for this release. The preview-synchronized release was validated with PostgreSQL 18 and PostGIS 3.6.2 through PGlite: 32 SQL checks passed, the standalone loader succeeded twice, and sign coordinates matched GeoJSON. The 2026-11-04 validation report is retained separately as a historical record. Frozen GeoJSON layer fingerprints are recorded in `source/locked_geojson_sha256.json`. The export registers, GeoPackage, KML, and workbook carry the same current feature counts.

```bash
npm install --no-save @electric-sql/pglite@0.5.15 @electric-sql/pglite-postgis@0.2.15
node source/verify_postgis.mjs
```

The workbook is editable and included. To regenerate it in an environment with `@oai/artifact-tool` installed, run the following after PostGIS verification.

```bash
python source/workbook_input.py > /tmp/educity-workbook.json
node source/build_register.mjs /tmp/educity-workbook.json EduCity_F3_Vertices_and_Features.xlsx
```
