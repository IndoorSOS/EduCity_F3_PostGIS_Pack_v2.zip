\set ON_ERROR_STOP on
CREATE OR REPLACE VIEW educity_f3.v_release_qa AS
WITH spatial AS (
  SELECT release_id,geom FROM educity_f3.floorplate UNION ALL
  SELECT release_id,geom FROM educity_f3.floorplate_vertices UNION ALL
  SELECT release_id,geom FROM educity_f3.zones UNION ALL
  SELECT release_id,geom FROM educity_f3.vertices UNION ALL
  SELECT release_id,geom FROM educity_f3.zone_wall_segments UNION ALL
  SELECT release_id,geom FROM educity_f3.lift_cars UNION ALL
  SELECT release_id,geom FROM educity_f3.stair_features UNION ALL
  SELECT release_id,geom FROM educity_f3.stair_flight_detail UNION ALL
  SELECT release_id,geom FROM educity_f3.exit_signs UNION ALL
  SELECT release_id,geom FROM educity_f3.door_access UNION ALL
  SELECT release_id,geom FROM educity_f3.single_doors UNION ALL
  SELECT release_id,swing_geom FROM educity_f3.single_doors WHERE swing_geom IS NOT NULL
)
SELECT d.release_id,q.check_name,q.expected,q.observed,q.observed=q.expected AS pass
FROM educity_f3.dataset_release d
CROSS JOIN LATERAL (VALUES
  ('floorplates',d.floorplate_count,(SELECT count(*) FROM educity_f3.floorplate WHERE release_id=d.release_id)),
  ('floorplate vertices',(SELECT sum(vertex_count) FROM educity_f3.floorplate WHERE release_id=d.release_id),
    (SELECT count(*) FROM educity_f3.floorplate_vertices WHERE release_id=d.release_id)),
  ('zones',d.zone_count,(SELECT count(*) FROM educity_f3.zones WHERE release_id=d.release_id)),
  ('zone vertices',d.vertex_count,(SELECT count(*) FROM educity_f3.vertices WHERE release_id=d.release_id)),
  ('zone boundaries',d.wall_segment_count,(SELECT count(*) FROM educity_f3.zone_wall_segments WHERE release_id=d.release_id)),
  ('lift cars',d.lift_car_count,(SELECT count(*) FROM educity_f3.lift_cars WHERE release_id=d.release_id)),
  ('stair features',d.stair_feature_count,(SELECT count(*) FROM educity_f3.stair_features WHERE release_id=d.release_id)),
  ('exit signs',d.exit_sign_count,(SELECT count(*) FROM educity_f3.exit_signs WHERE release_id=d.release_id)),
  ('egress links',d.egress_link_count,(SELECT count(*) FROM educity_f3.egress_links WHERE release_id=d.release_id)),
  ('invalid geometry or CRS',0,(SELECT count(*) FROM spatial g WHERE g.release_id=d.release_id
    AND (g.geom IS NULL OR ST_IsEmpty(g.geom) OR NOT ST_IsValid(g.geom) OR ST_SRID(g.geom)<>4326 OR ST_NDims(g.geom)<>2))),
  ('zone metrics outside tolerance',0,(SELECT count(*) FROM educity_f3.zones z WHERE z.release_id=d.release_id
    AND (abs(ST_Area(ST_Transform(z.geom,3877))-z.area_m2)>0.002
      OR abs(ST_Perimeter(ST_Transform(z.geom,3877))-z.perimeter_m)>0.002))),
  ('zone overlaps above 0.00001 m²',0,(SELECT count(*) FROM educity_f3.zones a
    JOIN educity_f3.zones b ON a.release_id=b.release_id AND a.zone_id<b.zone_id AND a.geom && b.geom
    WHERE a.release_id=d.release_id
      AND ST_Area(ST_Transform(ST_Intersection(a.geom,b.geom),3877))>0.00001)),
  ('zones outside floorplate above 0.00001 m²',0,(SELECT count(*) FROM educity_f3.zones z
    JOIN educity_f3.floorplate f USING(release_id)
    WHERE z.release_id=d.release_id AND ST_Area(ST_Transform(ST_Difference(z.geom,f.geom),3877))>0.00001)),
  ('vertex links missing zone',0,(SELECT count(*) FROM educity_f3.vertices v
    LEFT JOIN educity_f3.zones z USING(release_id,zone_id) WHERE v.release_id=d.release_id AND z.zone_id IS NULL)),
  ('boundary endpoints different from vertex register',0,(SELECT count(*) FROM educity_f3.zone_wall_segments w
    LEFT JOIN educity_f3.vertices a ON a.release_id=w.release_id AND a.point_id=w.from_point_id AND a.zone_id=w.zone_id
    LEFT JOIN educity_f3.vertices b ON b.release_id=w.release_id AND b.point_id=w.to_point_id AND b.zone_id=w.zone_id
    WHERE w.release_id=d.release_id AND (a.geom IS NULL OR b.geom IS NULL
      OR NOT ST_Equals(a.geom,ST_StartPoint(w.geom)) OR NOT ST_Equals(b.geom,ST_EndPoint(w.geom))))),
  ('invalid sign zone references or positions',0,(SELECT count(*) FROM educity_f3.exit_signs s
    LEFT JOIN educity_f3.zones z USING(release_id,zone_id) LEFT JOIN educity_f3.floorplate f USING(release_id)
    WHERE s.release_id=d.release_id AND (z.zone_id IS NULL OR f.geom IS NULL OR NOT ST_Covers(f.geom,s.geom)
      OR ST_X(s.geom)<>s.longitude OR ST_Y(s.geom)<>s.latitude))),
  ('broken sign adjacency links',0,(SELECT count(*) FROM educity_f3.egress_links e
    LEFT JOIN educity_f3.exit_signs s USING(release_id,sign_id)
    LEFT JOIN educity_f3.zones a ON a.release_id=e.release_id AND a.zone_id=e.from_area
    LEFT JOIN educity_f3.zones b ON b.release_id=e.release_id AND b.zone_id=e.to_area
    WHERE e.release_id=d.release_id AND (s.sign_id IS NULL OR e.master_id IS DISTINCT FROM s.master_id
      OR e.fw_adv_id IS DISTINCT FROM s.fw_adv_id OR e.from_area IS DISTINCT FROM s.adjacent_area_a
      OR e.to_area IS DISTINCT FROM s.adjacent_area_b OR (e.from_area IS NOT NULL AND a.zone_id IS NULL)
      OR (e.to_area IS NOT NULL AND b.zone_id IS NULL)))),
  ('door access line features',CASE WHEN d.release_id='educity-f3-20261105-postgis-v2' THEN 136 ELSE 0 END,
    (SELECT count(*) FROM educity_f3.door_access WHERE release_id=d.release_id)),
  ('door access thresholds',CASE WHEN d.release_id='educity-f3-20261105-postgis-v2' THEN 66 ELSE 0 END,
    (SELECT count(*) FROM educity_f3.door_access WHERE release_id=d.release_id AND part='threshold')),
  ('thresholds linked to exit signs',d.exit_sign_count,
    (SELECT count(DISTINCT sign_id) FROM educity_f3.door_access WHERE release_id=d.release_id AND part='threshold')),
  ('invalid room door references or position',0,(SELECT count(*) FROM educity_f3.door_access a
    LEFT JOIN educity_f3.egress_links e USING(release_id,egress_id,sign_id)
    LEFT JOIN educity_f3.exit_signs s USING(release_id,sign_id)
    LEFT JOIN educity_f3.floorplate f ON f.release_id=a.release_id
    LEFT JOIN educity_f3.zones z ON z.release_id=a.release_id AND z.zone_id=a.zone_id
    LEFT JOIN educity_f3.zones b ON b.release_id=a.release_id AND b.zone_id=a.adjacent_zone_id
    WHERE a.release_id=d.release_id AND (f.geom IS NULL OR NOT ST_Covers(f.geom,a.geom) OR z.geom IS NULL
      OR (a.adjacent_zone_id IS NOT NULL AND b.geom IS NULL)
      OR ((a.egress_id IS NOT NULL OR a.sign_id IS NOT NULL) AND e.egress_id IS NULL)
      OR (a.part='threshold' AND (
        abs(ST_Length(ST_Transform(a.geom,3877))-a.opening_m)>0.002
        OR NOT ST_DWithin(ST_Transform(a.geom,3877),ST_Transform(z.geom,3877),0.75)
        OR (b.geom IS NOT NULL AND NOT ST_DWithin(ST_Transform(a.geom,3877),ST_Transform(b.geom,3877),0.75))
        OR (s.geom IS NOT NULL AND NOT ST_DWithin(ST_Transform(a.geom,3877),ST_Transform(s.geom,3877),1))))))),
  ('invalid access part sets',0,(SELECT count(*) FROM (
    SELECT access_id FROM educity_f3.door_access WHERE release_id=d.release_id
    GROUP BY access_id
    HAVING count(*) FILTER (WHERE part='threshold')<>1 OR count(DISTINCT feature_type)<>1
      OR count(*)<>CASE min(feature_type) WHEN 'double_leaf_door' THEN 3 WHEN 'single_leaf_door' THEN 2 ELSE 1 END
  ) AS invalid)),
  ('door swings missing matching hinge',0,(SELECT count(*) FROM educity_f3.door_access a
    LEFT JOIN educity_f3.door_access t ON t.release_id=a.release_id AND t.access_id=a.access_id AND t.part='threshold'
    WHERE a.release_id=d.release_id AND a.part<>'threshold'
      AND (t.geom IS NULL OR NOT ST_Equals(ST_StartPoint(a.geom),
        CASE WHEN a.part IN ('upper_leaf_swing','leaf_1_swing') THEN ST_StartPoint(t.geom) ELSE ST_EndPoint(t.geom) END)))),
  ('stair flight bands',14,(SELECT count(*) FROM educity_f3.stair_flight_detail
    WHERE release_id=d.release_id AND feature_type='stair_flight')),
  ('stair tread polygons',83,(SELECT count(*) FROM educity_f3.stair_flight_detail
    WHERE release_id=d.release_id AND feature_type='stair_tread')),
  ('stair landing polygons',14,(SELECT count(*) FROM educity_f3.stair_flight_detail
    WHERE release_id=d.release_id AND feature_type='stair_landing')),
  ('terrace stair review candidates',2,(SELECT count(*) FROM educity_f3.stair_flight_detail
    WHERE release_id=d.release_id AND feature_type='stair_candidate')),
  ('invalid stair detail parent or containment',0,(SELECT count(*) FROM educity_f3.stair_flight_detail s
    LEFT JOIN educity_f3.zones z ON z.release_id=s.release_id AND z.zone_id=s.parent_zone_id
    WHERE s.release_id=d.release_id AND (
      z.category IS DISTINCT FROM CASE WHEN s.feature_type='stair_candidate' THEN 'terrace' ELSE 'stair' END
      OR s.travel_direction_status<>'unverified'
      OR ST_Area(ST_Difference(ST_Transform(s.geom,3877),ST_Transform(z.geom,3877)))>0.0001))),
  ('treads mismatched to flight',0,(SELECT count(*) FROM educity_f3.stair_flight_detail t
    LEFT JOIN educity_f3.stair_flight_detail f ON f.release_id=t.release_id AND f.feature_id=t.flight_id
    WHERE t.release_id=d.release_id AND t.feature_type='stair_tread' AND (
      f.feature_type IS DISTINCT FROM 'stair_flight' OR f.parent_zone_id IS DISTINCT FROM t.parent_zone_id
      OR t.tread_index>f.visible_tread_count
      OR EXISTS (SELECT 1 FROM ST_DumpPoints(t.geom) p
        WHERE NOT ST_DWithin(p.geom,f.geom,0.000000001))))),
  ('flight tread counts or coverage differ',0,(SELECT count(*) FROM educity_f3.stair_flight_detail f
    LEFT JOIN LATERAL (SELECT count(*) AS n,sum(ST_Area(ST_Transform(geom,3877))) AS area
      FROM educity_f3.stair_flight_detail WHERE release_id=f.release_id AND flight_id=f.feature_id
      AND feature_type='stair_tread') AS t ON true
    WHERE f.release_id=d.release_id AND f.feature_type='stair_flight' AND (
      t.n<>f.visible_tread_count OR abs(ST_Area(ST_Transform(f.geom,3877))-t.area)>0.0001))),
  ('overlapping stair components',0,(SELECT count(*) FROM educity_f3.stair_flight_detail a
    JOIN educity_f3.stair_flight_detail b ON b.release_id=a.release_id AND b.parent_zone_id=a.parent_zone_id
      AND a.feature_id<b.feature_id AND a.geom && b.geom
    WHERE a.release_id=d.release_id AND (
      (a.feature_type IN ('stair_flight','stair_landing') AND b.feature_type IN ('stair_flight','stair_landing'))
      OR (a.feature_type='stair_tread' AND b.feature_type='stair_tread' AND a.flight_id=b.flight_id))
      AND ST_Area(ST_Intersection(ST_Transform(a.geom,3877),ST_Transform(b.geom,3877)))>0.0001)),
  ('invalid stair parents',0,(SELECT count(*) FROM educity_f3.stair_features s
    LEFT JOIN educity_f3.zones z ON z.release_id=s.release_id AND z.zone_id=s.parent_zone_id
    WHERE s.release_id=d.release_id AND (z.category IS DISTINCT FROM 'stair' OR NOT ST_Equals(s.geom,z.geom))))
) AS q(check_name,expected,observed);

DO $$
DECLARE target CONSTANT text := 'educity-f3-20261105-postgis-v2';
DECLARE failures text;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM educity_f3.dataset_release WHERE release_id=target
    AND crs='EPSG:4326' AND metric_crs='EPSG:3877' AND survey_grade IS FALSE) THEN
    RAISE EXCEPTION 'EduCity release is missing or has unexpected registration metadata';
  END IF;
  SELECT string_agg(format('%s (expected %s, found %s)',check_name,expected,observed), ', ')
    INTO failures FROM educity_f3.v_release_qa WHERE release_id=target AND pass IS NOT TRUE;
  IF failures IS NOT NULL THEN
    RAISE EXCEPTION 'EduCity validation failed: %',failures;
  END IF;
END $$;

SELECT * FROM educity_f3.v_release_qa
WHERE release_id='educity-f3-20261105-postgis-v2' ORDER BY check_name;
