\set ON_ERROR_STOP on
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE SCHEMA IF NOT EXISTS educity_f3;

CREATE TABLE IF NOT EXISTS educity_f3.dataset_release (
  release_id text PRIMARY KEY, site_id text NOT NULL, level_id text NOT NULL, level_name text,
  address text, as_of_date date, crs text, metric_crs text, coordinate_order text,
  dimensionality text, survey_grade boolean, floorplate_count integer, zone_count integer,
  vertex_count integer, wall_segment_count integer, lift_car_count integer,
  stair_feature_count integer, exit_sign_count integer, egress_link_count integer, review_state text
);
CREATE TABLE IF NOT EXISTS educity_f3.floorplate (
  release_id text REFERENCES educity_f3.dataset_release, site_id text, level_id text,
  feature_id text, feature_type text, vertex_count integer, area_m2 double precision,
  perimeter_m double precision, north_apex_screen_x double precision, north_apex_screen_y double precision,
  boundary_rendering text, review_state text, as_of_date date, geom geometry(Polygon,4326),
  PRIMARY KEY (release_id, feature_id)
);
CREATE TABLE IF NOT EXISTS educity_f3.floorplate_vertices (
  release_id text REFERENCES educity_f3.dataset_release, site_id text, level_id text,
  feature_id text, vertex_no integer, point_id text, screen_x double precision, screen_y double precision,
  source_x double precision, source_y double precision, longitude double precision, latitude double precision,
  sequence text, geom geometry(Point,4326), PRIMARY KEY (release_id, point_id)
);
CREATE TABLE IF NOT EXISTS educity_f3.zones (
  release_id text REFERENCES educity_f3.dataset_release, site_id text, level_id text, level_name text,
  floor_elevation_m double precision, zone_no integer, zone_id text, space text, category text,
  vertical_direction text, connects_to_level_id text, egress_role text, shape text, vertex_count integer,
  egress_profile_count integer, egress_link_count integer, area_m2 double precision,
  perimeter_m double precision, display_color text, review_state text, as_of_date date,
  geom geometry(Polygon,4326), PRIMARY KEY (release_id, zone_id)
);
CREATE TABLE IF NOT EXISTS educity_f3.vertices (
  release_id text REFERENCES educity_f3.dataset_release, site_id text, level_id text,
  global_point_no integer, zone_no integer, zone_id text, zone_point_no integer, point_id text,
  space text, screen_x double precision, screen_y double precision, source_x double precision,
  source_y double precision, longitude double precision, latitude double precision,
  vertex_sequence text, vertex_role text, plan_feature text, crs text, geom geometry(Point,4326),
  PRIMARY KEY (release_id, point_id)
);
CREATE TABLE IF NOT EXISTS educity_f3.zone_wall_segments (
  release_id text REFERENCES educity_f3.dataset_release, site_id text, level_id text,
  segment_id text, zone_id text, segment_no integer, boundary_class text, from_point_id text,
  to_point_id text, rendering text, geom geometry(LineString,4326), PRIMARY KEY (release_id, segment_id)
);
CREATE TABLE IF NOT EXISTS educity_f3.lift_cars (
  release_id text REFERENCES educity_f3.dataset_release, site_id text, level_id text,
  feature_id text, parent_zone_id text, feature_type text, lift_number integer, vertex_count integer,
  area_m2 double precision, perimeter_m double precision, geom geometry(Polygon,4326),
  PRIMARY KEY (release_id, feature_id)
);
CREATE TABLE IF NOT EXISTS educity_f3.stair_features (
  release_id text REFERENCES educity_f3.dataset_release, site_id text, level_id text,
  feature_id text, parent_zone_id text, feature_type text, flight text, step_number integer,
  pair_id text, paired_feature_id text, paired_level_id text,
  geometry_representation text, raster_dependency boolean, rendering text,
  vertex_count integer, area_m2 double precision, perimeter_m double precision,
  geom geometry(Polygon,4326), PRIMARY KEY (release_id, feature_id)
);
CREATE TABLE IF NOT EXISTS educity_f3.exit_signs (
  release_id text REFERENCES educity_f3.dataset_release, site_id text, level_id text,
  sign_id text, feature_type text, egress text, adjacent_area_a text, adjacent_area_b text,
  screen_x double precision, screen_y double precision, source_x double precision, source_y double precision,
  longitude double precision, latitude double precision, rotation_deg double precision,
  geom geometry(Point,4326), PRIMARY KEY (release_id, sign_id)
);
CREATE TABLE IF NOT EXISTS educity_f3.egress_links (
  release_id text REFERENCES educity_f3.dataset_release, site_id text, level_id text,
  egress_id text, sign_id text, from_area text, to_area text, description text,
  exit_sign_present boolean, geometry_basis text, PRIMARY KEY (release_id, egress_id)
);
CREATE INDEX IF NOT EXISTS idx_educity_f3_floorplate_geom ON educity_f3.floorplate USING gist (geom);
CREATE INDEX IF NOT EXISTS idx_educity_f3_zones_geom ON educity_f3.zones USING gist (geom);
CREATE INDEX IF NOT EXISTS idx_educity_f3_vertices_geom ON educity_f3.vertices USING gist (geom);
CREATE INDEX IF NOT EXISTS idx_educity_f3_walls_geom ON educity_f3.zone_wall_segments USING gist (geom);
CREATE INDEX IF NOT EXISTS idx_educity_f3_lifts_geom ON educity_f3.lift_cars USING gist (geom);
CREATE INDEX IF NOT EXISTS idx_educity_f3_stairs_geom ON educity_f3.stair_features USING gist (geom);
CREATE INDEX IF NOT EXISTS idx_educity_f3_signs_geom ON educity_f3.exit_signs USING gist (geom);

-- Exit Master IDs, 31 October 2026. Existing sign_id joins are retained.
ALTER TABLE educity_f3.exit_signs ADD COLUMN IF NOT EXISTS master_id text;
ALTER TABLE educity_f3.egress_links ADD COLUMN IF NOT EXISTS master_id text;
CREATE UNIQUE INDEX IF NOT EXISTS idx_educity_f3_exit_master_id ON educity_f3.exit_signs (release_id, master_id);

-- Canonical Exit IDs and legacy aliases, 31 October 2026.
ALTER TABLE educity_f3.exit_signs ADD COLUMN IF NOT EXISTS fw_adv_id text;
ALTER TABLE educity_f3.egress_links ADD COLUMN IF NOT EXISTS fw_adv_id text;

CREATE TABLE IF NOT EXISTS educity_f3.single_doors (release_id text REFERENCES educity_f3.dataset_release,site_id text,level_id text,feature_id text,from_zone_id text,to_zone_id text,door_type text,width_plan_units double precision,geom geometry(LineString,4326),swing_geom geometry(LineString,4326),PRIMARY KEY(release_id,feature_id));

-- EduCity ring and boundary provenance extensions.
ALTER TABLE educity_f3.vertices ADD COLUMN IF NOT EXISTS ring_index integer;
ALTER TABLE educity_f3.vertices ADD COLUMN IF NOT EXISTS ring_point_no integer;
ALTER TABLE educity_f3.zone_wall_segments ADD COLUMN IF NOT EXISTS ring_index integer;
ALTER TABLE educity_f3.zones ADD COLUMN IF NOT EXISTS source_name_en text;
ALTER TABLE educity_f3.zones ADD COLUMN IF NOT EXISTS source_name_fi text;
ALTER TABLE educity_f3.zones ADD COLUMN IF NOT EXISTS note text;
ALTER TABLE educity_f3.exit_signs ADD COLUMN IF NOT EXISTS zone_id text;
ALTER TABLE educity_f3.exit_signs ADD COLUMN IF NOT EXISTS position_status text;
ALTER TABLE educity_f3.egress_links ADD COLUMN IF NOT EXISTS route_status text;

-- Threshold and swing linework for door access without changing zone boundaries.
CREATE TABLE IF NOT EXISTS educity_f3.door_access (
  release_id text NOT NULL REFERENCES educity_f3.dataset_release,
  site_id text NOT NULL, level_id text NOT NULL,
  feature_id text NOT NULL, access_id text NOT NULL, zone_id text NOT NULL,
  egress_id text NOT NULL, sign_id text NOT NULL, feature_type text NOT NULL,
  part text NOT NULL CHECK (part IN ('threshold','upper_leaf_swing','lower_leaf_swing','leaf_1_swing','leaf_2_swing')),
  location text NOT NULL, swing_toward text NOT NULL, opening_m double precision,
  review_state text NOT NULL, geom geometry(LineString,4326) NOT NULL,
  PRIMARY KEY (release_id, feature_id), UNIQUE (release_id, access_id, part),
  CHECK ((part='threshold' AND opening_m IS NOT NULL AND opening_m>0)
    OR (part<>'threshold' AND opening_m IS NULL))
);
CREATE INDEX IF NOT EXISTS idx_educity_f3_door_access_geom ON educity_f3.door_access USING gist (geom);

-- Broaden the entrance-only register to unmarked room doors and lift entrances.
ALTER TABLE educity_f3.door_access ADD COLUMN IF NOT EXISTS adjacent_zone_id text;
ALTER TABLE educity_f3.door_access ALTER COLUMN sign_id DROP NOT NULL;
ALTER TABLE educity_f3.door_access ALTER COLUMN egress_id DROP NOT NULL;
ALTER TABLE educity_f3.door_access ALTER COLUMN swing_toward DROP NOT NULL;
ALTER TABLE educity_f3.door_access DROP CONSTRAINT IF EXISTS door_access_part_check;
ALTER TABLE educity_f3.door_access ADD CONSTRAINT door_access_part_check
  CHECK (part IN ('threshold','upper_leaf_swing','lower_leaf_swing','leaf_1_swing','leaf_2_swing'));

-- Draft 2D stair detail preserves the approved stair core polygons.
CREATE TABLE IF NOT EXISTS educity_f3.stair_flight_detail (
  release_id text NOT NULL, site_id text NOT NULL, level_id text NOT NULL,
  feature_id text NOT NULL, parent_zone_id text NOT NULL,
  feature_type text NOT NULL CHECK (feature_type IN ('stair_flight','stair_tread','stair_landing','stair_candidate')),
  plan_position text NOT NULL, flight_id text, tread_index integer, visible_tread_count integer,
  source_visibility text NOT NULL, travel_direction_status text NOT NULL,
  area_m2 double precision NOT NULL, perimeter_m double precision NOT NULL,
  geom geometry(Polygon,4326) NOT NULL,
  PRIMARY KEY (release_id, feature_id),
  FOREIGN KEY (release_id, parent_zone_id) REFERENCES educity_f3.zones (release_id, zone_id),
  FOREIGN KEY (release_id, flight_id) REFERENCES educity_f3.stair_flight_detail (release_id, feature_id),
  UNIQUE (release_id, flight_id, tread_index),
  CHECK (area_m2 > 0 AND perimeter_m > 0),
  CHECK (
    (feature_type='stair_flight' AND flight_id IS NOT NULL AND flight_id=feature_id AND tread_index IS NULL
      AND visible_tread_count IS NOT NULL AND visible_tread_count>0)
    OR (feature_type='stair_tread' AND flight_id IS NOT NULL AND tread_index IS NOT NULL AND tread_index>0
      AND visible_tread_count IS NULL)
    OR (feature_type IN ('stair_landing','stair_candidate') AND flight_id IS NULL AND tread_index IS NULL
      AND visible_tread_count IS NULL)
  )
);
CREATE INDEX IF NOT EXISTS idx_educity_f3_stair_flight_detail_geom
  ON educity_f3.stair_flight_detail USING gist (geom);
