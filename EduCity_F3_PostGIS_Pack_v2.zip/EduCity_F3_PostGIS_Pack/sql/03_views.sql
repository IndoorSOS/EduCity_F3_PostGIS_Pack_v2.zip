\set ON_ERROR_STOP on
CREATE OR REPLACE VIEW educity_f3.v_zone_summary AS
SELECT z.release_id,z.zone_id,z.space,z.category,z.vertical_direction,z.connects_to_level_id,
       z.vertex_count,z.egress_profile_count,z.egress_link_count,z.area_m2,z.perimeter_m,z.geom,
       z.display_color,z.source_name_en,z.source_name_fi,z.review_state
FROM educity_f3.zones z;

CREATE OR REPLACE VIEW educity_f3.v_egress_signs AS
SELECT e.release_id,e.egress_id,e.description,e.from_area,e.to_area,e.exit_sign_present,
       s.sign_id,s.rotation_deg,s.geom,s.master_id,s.fw_adv_id,s.zone_id,e.route_status
FROM educity_f3.egress_links e
LEFT JOIN educity_f3.exit_signs s USING (release_id,sign_id);

CREATE OR REPLACE VIEW educity_f3.v_stair_inventory AS
SELECT release_id,parent_zone_id,feature_type,flight,count(*) AS feature_count,
       ST_Collect(geom)::geometry(MultiPolygon,4326) AS geom
FROM educity_f3.stair_features
GROUP BY release_id,parent_zone_id,feature_type,flight;

CREATE OR REPLACE VIEW educity_f3.v_stair_pairs AS
SELECT release_id,feature_id,pair_id,paired_feature_id,paired_level_id,
       parent_zone_id,feature_type,flight,step_number,geom
FROM educity_f3.stair_features;

CREATE OR REPLACE VIEW educity_f3.v_lift_shafts AS
SELECT release_id,zone_id,space,area_m2,geom
FROM educity_f3.zones
WHERE category = 'lift';

CREATE OR REPLACE VIEW educity_f3.v_entrance_egress AS
SELECT d.release_id,d.site_id,d.level_id,d.feature_id,d.access_id,d.zone_id,
       d.egress_id,d.sign_id,d.feature_type,d.part,d.location,d.swing_toward,d.opening_m,
       d.review_state,e.route_status,d.geom
FROM educity_f3.door_access d
JOIN educity_f3.egress_links e USING(release_id,egress_id,sign_id)
WHERE d.access_id='EDU-F3-DA-01';

CREATE OR REPLACE VIEW educity_f3.v_room_door_access AS
SELECT d.*,e.route_status
FROM educity_f3.door_access d
LEFT JOIN educity_f3.egress_links e USING(release_id,egress_id,sign_id);

CREATE OR REPLACE VIEW educity_f3.v_stair_flights AS
SELECT * FROM educity_f3.stair_flight_detail
WHERE feature_type='stair_flight';
