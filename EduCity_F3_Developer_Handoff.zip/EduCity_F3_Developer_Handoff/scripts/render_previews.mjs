import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { Script } from 'node:vm';
import sharp from 'sharp';

const output = process.argv[2];
if (!output) {
    throw new Error('Pass the build output directory.');
}

const viewerPath = join(output, 'EduCity_F3_Trace_Review.html');
const viewer = await readFile(viewerPath, 'utf8');
const inlineProgram = viewer.match(/<script>([\s\S]*?)<\/script>/)?.[1];
if (!inlineProgram) {
    throw new Error('The offline viewer is missing its inline JavaScript.');
}
new Script(inlineProgram, { filename: viewerPath });

await sharp(join(output, 'EduCity_F3_Traced_Plan.svg'), { density: 125 })
    .png()
    .toFile(join(output, 'EduCity_F3_Trace_Preview.png'));

await sharp(join(output, 'EduCity_F3_Satellite_Alignment.svg'), { density: 125 })
    .resize({ width: 2000 })
    .png()
    .toFile(join(output, 'EduCity_F3_Satellite_Alignment.png'));

console.log('Rendered both PNG previews and checked the viewer JavaScript syntax.');
