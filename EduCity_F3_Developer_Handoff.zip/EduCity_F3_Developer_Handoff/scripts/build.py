"""Build the portable EduCity F3 demo in a new output directory."""

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from xml.etree import ElementTree


ROOT = Path(__file__).resolve().parents[1]
STAGES = (
    "build_trace.py",
    "add_exits_compass.py",
    "apply_rooftop_cover.py",
    "restore_signs_compass.py",
    "validate_geometry.py",
)
SVG = "{http://www.w3.org/2000/svg}"


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def verify_outputs(output):
    data = json.loads((output / "EduCity_F3_Trace_Data.json").read_text(encoding="utf-8"))
    signs = [item["sign_id"] for item in data["exit_signs"]]
    register = read_csv(output / "EduCity_F3_Exit_Sign_Register.csv")
    if len(set(signs)) != 17 or [row["sign_id"] for row in register] != signs:
        raise ValueError("Expected 17 unique signs with matching register IDs and order")

    svg = ElementTree.parse(output / "EduCity_F3_Satellite_Alignment.svg").getroot()
    elements = {node.get("id"): node for node in svg.iter() if node.get("id")}
    marker_ids = [node.get("data-sign") for node in elements["exitSigns"]]
    if marker_ids != signs:
        raise ValueError("Satellite symbols do not match the exit-sign register")
    compass = {node.text for node in elements["satelliteCompass"].iter(SVG + "text")}
    if not {"N", "NE", "E", "SE", "S", "SW", "W", "NW"} <= compass:
        raise ValueError("Satellite compass directions are incomplete")
    zones = [node for node in elements["zones"] if node.get("data-id")]
    if len(zones) != len(data["zones"]) or any(node.get("fill-opacity") != "1" for node in zones):
        raise ValueError("Satellite zone colours must cover the full traced floor")
    if elements["roofCoverBase"].get("fill-opacity") != "1":
        raise ValueError("The rooftop base must be opaque")


def write_checksums(output):
    lines = []
    for path in sorted(output.iterdir()):
        if path.is_file() and path.name != "SHA256SUMS.txt":
            lines.append(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.name}")
    (output / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def build(destination, skip_previews):
    if destination.exists():
        raise SystemExit(f"Choose a new output directory. This path already exists: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".educity-build-", dir=destination.parent) as staging:
        output = Path(staging) / "result"
        output.mkdir()
        env = dict(os.environ, EDUCITY_OUTPUT_DIR=str(output), PYTHONUTF8="1")
        for stage in STAGES:
            subprocess.run([sys.executable, str(ROOT / "src" / stage)], env=env, check=True)
        verify_outputs(output)
        if not skip_previews:
            subprocess.run(["node", str(ROOT / "scripts/render_previews.mjs"), str(output)], check=True)
        write_checksums(output)
        output.rename(destination)
    print(f"Built and verified {destination}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "build", help="New destination directory")
    parser.add_argument("--skip-previews", action="store_true", help="Build HTML, SVG and data with Python only")
    args = parser.parse_args()
    build(args.output.resolve(), args.skip_previews)


if __name__ == "__main__":
    main()
