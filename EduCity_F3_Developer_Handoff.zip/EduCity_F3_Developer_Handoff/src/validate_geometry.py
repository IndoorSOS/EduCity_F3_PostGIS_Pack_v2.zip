from pathlib import Path
import csv
import json
import os
import xml.etree.ElementTree as ET
import numpy as np
from PIL import Image,ImageDraw

p = Path(os.environ["EDUCITY_OUTPUT_DIR"])
d=json.loads((p/'EduCity_F3_Trace_Data.json').read_text())
def edge_distance(point,a,b):
    x,y=point;dx=b[0]-a[0];dy=b[1]-a[1]
    t=max(0,min(1,((x-a[0])*dx+(y-a[1])*dy)/(dx*dx+dy*dy)))
    return ((x-a[0]-t*dx)**2+(y-a[1]-t*dy)**2)**.5
def on_boundary(point,z):
    return any(edge_distance(point,r[i],r[(i+1)%len(r)])<1e-6 for r in z['rings'] for i in range(len(r)))
masks=[]
for z in d['zones']:
    m=Image.new('L',(1448,1604));a=ImageDraw.Draw(m)
    for i,r in enumerate(z['rings']):a.polygon([((x+88)*2,y*2) for x,y in r],fill=1 if i==0 else 0)
    masks.append(np.array(m)[1::2,1::2].astype(bool))
overlaps=[]
for i in range(len(masks)):
    for j in range(i):
        ys,xs=np.where(masks[i]&masks[j]);count=0
        for x,y in zip(xs,ys):
            point=(x-88+.5,y+.5)
            if not on_boundary(point,d['zones'][i]) and not on_boundary(point,d['zones'][j]):count+=1
        if count:overlaps.append([d['zones'][j]['id'],d['zones'][i]['id'],count])
qa=json.loads((p/'QA.json').read_text())
qa['interior_overlap_pairs_at_source_pixel_centres']=overlaps
qa['svg_xml_parsed']=ET.parse(p/'EduCity_F3_Traced_Plan.svg').getroot().tag.endswith('svg')
with (p/'EduCity_F3_Zone_Register.csv').open(encoding='utf-8-sig') as f:
    rows=list(csv.DictReader(f));qa['csv_zone_ids_match_json']=[r['zone_id'] for r in rows]==[z['id'] for z in d['zones']]
qa['html_contains_embedded_source']='data:image/png;base64,' in (p/'EduCity_F3_Trace_Review.html').read_text()
assert not overlaps and not qa['ring_checks'] and qa['unique_region_ids'] and qa['csv_zone_ids_match_json']
(p/'QA.json').write_text(json.dumps(qa,indent=2))
