from pathlib import Path
import xml.etree.ElementTree as E
import json
import math
import os
import re

PACK = Path(os.environ["EDUCITY_OUTPUT_DIR"])
NS='http://www.w3.org/2000/svg';E.register_namespace('',NS)
def tag(name):return '{'+NS+'}'+name
data=json.loads((PACK/'EduCity_F3_Trace_Data.json').read_text())
original_signs=json.dumps(data['exit_signs'],sort_keys=True)
matrix='matrix('+','.join(map(str,data['alignment']['svg_matrix']))+')'

def satellite_compass():
    g=E.Element(tag('g'),{'id':'satelliteCompass','class':'satellite-compass','pointer-events':'none'})
    defs=E.SubElement(g,tag('defs'));clip=E.SubElement(defs,tag('clipPath'),{'id':'satelliteDirectionClip'})
    E.SubElement(clip,tag('path'),{'d':'M0,0 H632 V800 H0 V423 H-88 V380 H0 Z','transform':matrix})
    rays=E.SubElement(g,tag('g'),{'clip-path':'url(#satelliteDirectionClip)'})
    lines=[(673,175,673,875),(330,525,1015,525),(413,785,933,265),(423,275,923,775)]
    for x1,y1,x2,y2 in lines:
        attrs={'x1':str(x1),'y1':str(y1),'x2':str(x2),'y2':str(y2),'stroke-dasharray':'5 9'}
        E.SubElement(rays,tag('line'),dict(attrs,stroke='white',**{'stroke-width':'2','opacity':'.32'}))
        E.SubElement(rays,tag('line'),dict(attrs,stroke='#315d79',**{'stroke-width':'.9','opacity':'.36'}))
    labels=E.SubElement(g,tag('g'),{'font-family':'Arial,sans-serif','font-size':'13','font-weight':'700','text-anchor':'middle','fill':'#23485e','stroke':'white','stroke-width':'3','paint-order':'stroke'})
    for name,x,y in [('N',673,182),('NE',947,252),('E',1017,529),('SE',944,795),('S',673,891),('SW',398,795),('W',327,529),('NW',399,255)]:
        E.SubElement(labels,tag('text'),{'x':str(x),'y':str(y)}).text=name
    rose=E.SubElement(g,tag('g'),{'font-family':'Arial,sans-serif','text-anchor':'middle'})
    E.SubElement(rose,tag('circle'),{'cx':'1080','cy':'235','r':'61','fill':'white','fill-opacity':'.94','stroke':'#b8cbd6','stroke-width':'1'})
    for i,name in enumerate(['N','NE','E','SE','S','SW','W','NW']):
        a=math.radians(i*45);dx,dy=math.sin(a),-math.cos(a)
        E.SubElement(rose,tag('line'),{'x1':str(1080-dx*6),'y1':str(235-dy*6),'x2':str(1080+dx*39),'y2':str(235+dy*39),'stroke':'#a82144' if i==0 else '#315d79','stroke-width':'2' if i%2==0 else '1'})
        E.SubElement(rose,tag('text'),{'x':str(1080+dx*50),'y':str(239+dy*50),'font-size':'13' if i%2==0 else '10','font-weight':'700','fill':'#a82144' if i==0 else '#315d79'}).text=name
    E.SubElement(rose,tag('polygon'),{'points':'1080,196 1075,211 1085,211','fill':'#a82144'})
    E.SubElement(rose,tag('text'),{'x':'1080','y':'312','font-size':'11','fill':'#23485e'}).text='NORTH · satellite view'
    return g

def restore_svg(svg,interactive=False):
    root=E.fromstring(svg)
    byid={x.get('id'):x for x in root.iter() if x.get('id')}
    signs=byid['exitSigns'];n=0
    for g in signs:
        if g.get('data-sign'):
            im=g.find(tag('image'));assert im is not None
            x,y,w,h=[float(im.get(k)) for k in ['x','y','width','height']];cx=x+w/2;cy=y+h/2
            g.set('transform',f'translate({cx} {cy}) scale(1.65) translate({-cx} {-cy})')
            # A thin white edge keeps the green source icon distinct from zone fills.
            frame=E.Element(tag('rect'),{'x':str(x-.6),'y':str(y-.6),'width':str(w+1.2),'height':str(h+1.2),'rx':'1','fill':'white','stroke':'white','stroke-width':'1'})
            g.insert(list(g).index(im),frame);n+=1
    assert n==17
    byid['exitSignIds'].set('font-size','8.5')
    if not interactive:
        byid['compass'].set('display','none')
    root.append(satellite_compass())
    return E.tostring(root,encoding='unicode')

satfile=PACK/'EduCity_F3_Satellite_Alignment.svg'
satfile.write_text(restore_svg(satfile.read_text()))
pagefile=PACK/'EduCity_F3_Trace_Review.html'
page=pagefile.read_text();start=page.index('<svg');end=page.index('</svg>',start)+len('</svg>')
page=page[:start]+restore_svg(page[start:end],interactive=True)+page[end:]
css='''
.satellite-compass{display:none}#plan.roof-cover .satellite-compass{display:inline}
#plan.roof-cover #compass{display:none!important}
#plan:not(.roof-cover) .exit-sign{transform:none}
'''
page=page.replace('</style>',css+'</style>',1)
page=page.replace("function updateExtra(){", "function updateExtra(){byId('satelliteCompass').style.visibility=byId('showCompass').checked?'visible':'hidden';",1)
page=re.sub('DRAFT 06 · 03 NOV 2026','DRAFT 07 · 03 NOV 2026',page)
pagefile.write_text(page)
data['metadata']['revision']='Draft 07 — visible exit signs and eight-direction satellite compass'
data['metadata']['satellite_exit_symbol_scale']=1.65
data['metadata']['satellite_compass_display']={'north_up':True,'cardinal_and_intercardinal_cross':True,'directions':['N','NE','E','SE','S','SW','W','NW'],'floor_bar':False}
assert original_signs==json.dumps(data['exit_signs'],sort_keys=True)
(PACK/'EduCity_F3_Trace_Data.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
qa=json.loads((PACK/'QA.json').read_text());qa['restored_exit_symbols_above_cover']=17;qa['exit_positions_ids_and_fw_fields_preserved']=True;qa['satellite_compass_eight_directions']=True;qa['solid_roof_cover_retained']=True;qa['floor_bar_added']=False
(PACK/'QA.json').write_text(json.dumps(qa,indent=2))
readme=(PACK/'README.txt').read_text();readme=readme.replace('Draft 06 /','Draft 07 /',1)
readme=readme.replace('REVISION 06','REVISION 07\nAll 17 corrected exit icons are drawn above the solid rooftop cover at 1.65x\ndisplay size. IDs, positions, FW fields and original icon direction are preserved.\nThe satellite view has a north-up compass and a subtle eight-direction cross,\nmatching the 7 City Road presentation convention. No floor bar is included.\n\nREVISION 06',1)
(PACK/'README.txt').write_text(readme)
print('Restored 17 visible signs; added eight-direction north-up satellite compass; preserved solid cover and all coordinates.')
