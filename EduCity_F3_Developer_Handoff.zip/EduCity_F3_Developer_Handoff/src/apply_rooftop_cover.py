"""Apply the opaque satellite roof cover to the existing Draft 05 outputs.

Run in the editable pack after generating the plan and satellite alignment.
The plan geometry, palette, source linework and 17 corrected signs are retained.
"""
from pathlib import Path
import json
import os
import re

ROOT = Path(os.environ["EDUCITY_OUTPUT_DIR"])
BASE = '<path id="roofCoverBase" d="M0,0 H632 V800 H0 V423 H-88 V380 H0 Z" fill="#e7e5df" fill-opacity="1" stroke="none" pointer-events="none"/>'

def insert_cover(text):
    if 'id="roofCoverBase"' not in text:
        text, n = re.subn(r'(<g id="zones"[^>]*>)', r'\1' + BASE, text, count=1)
        assert n == 1
    return text

sat_path = ROOT / 'EduCity_F3_Satellite_Alignment.svg'
sat = insert_cover(sat_path.read_text())
sat = sat.replace('opacity=".76"', 'opacity="1"', 1)
sat = sat.replace('fill-opacity=".34"', 'fill-opacity="1"')
sat = sat.replace('visual satellite alignment · 17 corrected exit signs', 'solid zone cover · 17 corrected exit signs')
sat_path.write_text(sat)

page_path = ROOT / 'EduCity_F3_Trace_Review.html'
page = insert_cover(page_path.read_text())
css = '\n#roofCoverBase{display:none;pointer-events:none}#plan.roof-cover #roofCoverBase{display:inline}#plan.roof-cover #zones path[data-id]{fill-opacity:1}\n'
if '#plan.roof-cover' not in page:
    page = page.replace('</style>', css + '</style>', 1)
page = page.replace('<option value="satellite">', '<option value="satellite" selected>', 1)
page = page.replace("const sat=currentView==='satellite';byId('satellite')", "const sat=currentView==='satellite';plan.classList.toggle('roof-cover',sat);byId('satellite')", 1)
page = page.replace('});updateExtra();\n</script>', '});updateExtra();setView();\n</script>', 1)
page = re.sub(r'DRAFT 0[1-5] · 03 NOV 2026', 'DRAFT 06 · 03 NOV 2026', page)
page_path.write_text(page)

data_path = ROOT / 'EduCity_F3_Trace_Data.json'
data = json.loads(data_path.read_text())
data['metadata']['revision'] = 'Draft 06 — solid zone colors cover the complete rooftop'
data['metadata']['satellite_roof_cover'] = {
    'zone_fill_opacity': 1,
    'scene_opacity': 1,
    'palette': 'Existing zone colors retained',
    'base_fill': '#e7e5df',
    'base_extent': 'Existing full roof footprint plus ICT-City connector; fills tiny unclassified gaps and prevents satellite bleed at polygon seams',
    'default_review_view': 'satellite',
    'floor_bar': False,
}
data_path.write_text(json.dumps(data, ensure_ascii=False, indent=2))

readme_path = ROOT / 'README.txt'
readme = readme_path.read_text()
readme = readme.replace('Draft 05 / 3 November 2026', 'Draft 06 / 3 November 2026', 1)
revision = ('REVISION 06\nSatellite view uses the existing zone palette at full opacity to cover the rooftop.\nA neutral footprint base masks small unclassified gaps and antialiased seams.\nThe interactive review opens on the north-up satellite cover. No floor bar is included.\nPlan view, region geometry, compass and all 17 corrected exit signs are preserved.\n\n')
if 'REVISION 06' not in readme:
    readme = readme.replace('REVISION 05', revision + 'REVISION 05', 1)
readme_path.write_text(readme)
print('Applied solid rooftop cover; floor bar omitted.')
