from pathlib import Path
from PIL import Image
import numpy as np
import base64
import csv
import html
import io
import json
import math
import os
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(os.environ["EDUCITY_OUTPUT_DIR"])
REF = ROOT / "assets/exit-sign-reference.png"
SAT = ROOT / "assets/satellite-underlay.svg"
REFERENCE_NAME = "Exit sign Complete.jpg"
data = json.loads((OUT / "EduCity_F3_Trace_Data.json").read_text(encoding="utf-8"))
im=Image.open(REF).convert('RGB')

# Corresponding outer wall corners in the annotated image. This transfer is
# between two views of the SAME drawing, unrelated to geographic surveying.
annotated_registration=dict(origin=[45,42],scale_x=665/632,scale_y=842/800,
    source_size=list(im.size),basis='Four corresponding outer wall corners of the same plan')
def local(x,y):return [(x-45)/(665/632),(y-42)/(842/800)]
# Bounding rectangles enclose the 17 corrected user-marked icons, including white symbols.
marked=[
 ('north_left',[270,150,283,171],'O1','O1 / N2 doorway',[-20,14]),
 ('north_middle',[386,139,407,152],'N1','Northern central doorway',[0,-17]),
 ('north_right',[483,150,497,171],'O2','O2 / N2 doorway',[18,14]),
 ('room_u09',[188,286,210,299],'U09','U09 doorway on study-space side',[-18,-14]),
 ('room_u17',[552,351,574,364],'U17','U17 doorway on study-space side',[15,-13]),
 ('west_stair',[68,436,90,449],'D1','ICT-City lobby / stair S01',[0,-15]),
 ('ict_link',[32,454,45,476],'D1','ICT-City connection',[-28,29]),
 ('west_workspace',[118,454,131,476],'P1','D1 / P1 doorway',[18,-16]),
 ('bridge_left',[270,465,283,486],'B1','P1 / B1 doorway, corrected marked position',[16,23]),
 ('bridge_right',[483,465,496,486],'B1','B1 / P2 doorway',[-20,22]),
 ('workspace_partition',[547,466,560,488],'P2','P2 internal partition doorway',[-20,8]),
 ('east_lobby',[627,454,640,477],'H1','P2 / H1 doorway',[-24,-17]),
 ('east_stair',[668,439,690,452],'H1','H1 / stair S02',[0,-16]),
 ('east_terrace',[616,584,638,597],'R1','P2 / R1 terrace doorway',[0,21]),
 ('cafeteria_left',[119,666,141,679],'Q1','P1 / Q1 doorway, left marked position',[-8,-15]),
 ('cafeteria_right',[188,666,210,679],'Q1','P1 / Q1 doorway, right marked position',[8,-15]),
 ('cafeteria_terrace',[270,701,284,723],'Q1','Q1 / R1 terrace doorway',[24,0])]
signs=[]
for key,box,zone,description,offset in marked:
    x1,y1,x2,y2=box;x,y=local((x1+x2)/2,(y1+y2)/2)
    # Embed the supplied artwork, retaining the marked icon's displayed direction.
    crop=im.crop(box);buf=io.BytesIO();crop.save(buf,format='PNG')
    signs.append(dict(key=key,site_id='',level_id='F3',sign_id='',sign_type='exit_sign',
        zone_id='EDU-F3-'+zone,description=description,fw_adv_id='',
        x_px=round(x,3),y_px=round(y,3),source_x_px=round(x+857,3),source_y_px=round(y+70,3),
        marked_image_bbox=box,marked_image_center=[(x1+x2)/2,(y1+y2)/2],
        icon_width_px=(x2-x1)/(665/632),icon_height_px=(y2-y1)/(842/800),
        display_orientation='horizontal' if x2-x1>y2-y1 else 'vertical',
        icon_data_url='data:image/png;base64,'+base64.b64encode(buf.getvalue()).decode(),
        label_offset=offset,longitude=None,latitude=None,egress_bearing_deg=None,
        position_basis='Transferred from user-marked image; adjacent-zone association',
        status='user_marked_position; uncommissioned'))
centre=np.array([316.,400.])
start=next(s for s in signs if s['key']=='ict_link')
start_angle=math.atan2(-(start['y_px']-400),start['x_px']-316)
def sequence(s):return (math.atan2(-(s['y_px']-400),s['x_px']-316)-start_angle)%(2*math.pi)
signs.sort(key=sequence)
for i,s in enumerate(signs,1):s['sign_id']=f'EDU-F3-ES-{i:02}';s['number']=i

# Visual control corners on the north-up satellite image. Roof height and
# image perspective mean this is an orientation check, not a surveyed footprint.
src=np.array([[0,0],[632,0],[632,800],[0,800]],float)
dst=np.array([[715,196],[984,413],[634,854],[361,637]],float)
co=np.linalg.lstsq(np.c_[src,np.ones(4)],dst,rcond=None)[0]
A=co[:2].T;t=co[2]
residual=np.linalg.norm(np.c_[src,np.ones(4)]@co-dst,axis=1)
top_vector=-A[:,1]
bearing=math.degrees(math.atan2(top_vector[0],-top_vector[1]))%360
matrix=[A[0,0],A[1,0],A[0,1],A[1,1],t[0],t[1]]
matrix_svg='matrix('+','.join(f'{v:.9f}' for v in matrix)+')'
satellite = ET.parse(SAT).getroot()
sat_im = (int(satellite.get("width")), int(satellite.get("height")))
alignment=dict(method='Visual affine fit to the complete outer roof footprint, including the blue street-side roof strip, in north-up Google satellite view',
    satellite_url='https://www.google.com/maps/@60.44855,22.29715,138m/data=!3m1!1e3?entry=ttu&g_ep=EgoyMDI2MTAyOC4wIKXMDSoASAFQAw%3D%3D',
    source_control_points_px=src.tolist(),satellite_control_points_px=dst.tolist(),
    svg_matrix=matrix,plan_up_true_bearing_deg=round(bearing,3),
    control_fit_residual_px=residual.round(3).tolist(),satellite_image_size=list(sat_im),
    status='approximate visual orientation; no surveyed geographic coordinates',
    note='Control-fit residual is only internal image fitting, not positional accuracy. Roof displacement and lower-floor setbacks remain unmeasured.')
data['exit_signs']=signs;data['alignment']=alignment
data['metadata']['revision']='Draft 05 — corrected signs and full-rooftop satellite overlay'
data['metadata']['satellite_overlay_extent']='Extended to the complete outer roof edge, including the blue street-side roof strip; local floor-plan geometry is preserved.'
data['metadata']['exit_sign_correction']='Supersedes the previous 15-sign annotation with Exit sign Complete.jpg: 17 signs, no middle connector sign, corrected left connector position and added U09, U17 and P2 partition markers.'
data['metadata']['coordinate_system']['north']='Approximate orientation from north-up satellite visual match'
data['metadata']['coordinate_system']['georeferenced']=False
data['metadata']['exit_sign_numbering']='Provisional anticlockwise angular order around floor centre, beginning at the ICT-City link. No geographic direction suffix assigned.'
data['metadata']['exit_marker_image_registration']=annotated_registration
data['metadata']['sources'].append(dict(name=REFERENCE_NAME,type='user supplied exit-sign annotations'))
(OUT/'EduCity_F3_Trace_Data.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
with (OUT/'EduCity_F3_Exit_Sign_Register.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['site_id','level_id','sign_id','FW Adv id','sign_type','zone_id','description','local_x_px','local_y_px','source_x_px','source_y_px','longitude','latitude','egress_bearing_deg','status'])
    for s in signs:w.writerow(['','F3',s['sign_id'],'','exit_sign',s['zone_id'],s['description'],s['x_px'],s['y_px'],s['source_x_px'],s['source_y_px'],'','','',s['status']])

def mapdir(deg):
    d=np.array([math.sin(math.radians(deg)),-math.cos(math.radians(deg))])
    v=np.linalg.solve(A,d);return v/np.linalg.norm(v)
def compass_layer():
    s=['<defs><clipPath id="compassClip"><rect x="0" y="0" width="632" height="800"/></clipPath></defs>',
       '<g id="compass" pointer-events="none">',
       '<g clip-path="url(#compassClip)" stroke="#315d79" stroke-width=".8" opacity=".12" stroke-dasharray="5 7">']
    for deg in [0,45,90,135]:
        v=mapdir(deg)*650;s.append(f'<line x1="{316-v[0]:.3f}" y1="{400-v[1]:.3f}" x2="{316+v[0]:.3f}" y2="{400+v[1]:.3f}"/>')
    s+=['</g><g font-family="Arial,sans-serif" text-anchor="middle">']
    cx,cy=-52,108
    s.append(f'<circle cx="{cx}" cy="{cy}" r="37" fill="white" fill-opacity=".92" stroke="#d6e1e8" stroke-width=".8"/>')
    for k,name in enumerate(['N','NE','E','SE','S','SW','W','NW']):
        v=mapdir(k*45);r=25 if len(name)==1 else 26
        colour='#a82144' if k==0 else '#31526b';thick=1.5 if k==0 else .7
        s.append(f'<line x1="{cx-v[0]*4:.3f}" y1="{cy-v[1]*4:.3f}" x2="{cx+v[0]*r:.3f}" y2="{cy+v[1]*r:.3f}" stroke="{colour}" stroke-width="{thick}"/>')
        s.append(f'<text x="{cx+v[0]*32:.3f}" y="{cy+v[1]*32+2:.3f}" font-size="{7.5 if k%2==0 else 5.8}" fill="{colour}" font-weight="700">{name}</text>')
        if k==0:
            tip=np.array([cx,cy])+v*25;side=np.array([-v[1],v[0]])
            pts=[tip,tip-v*8+side*3,tip-v*8-side*3]
            s.append('<polygon points="'+' '.join(f'{x:.3f},{y:.3f}' for x,y in pts)+'" fill="#a82144"/>')
    s.append(f'<text x="{cx}" y="{cy+49}" font-size="6.6" fill="#31526b">Satellite-matched north</text>')
    s.append(f'<text x="{cx}" y="{cy+60}" font-size="6.2" fill="#647a89">Plan up ≈ {bearing:.0f}° NE</text>')
    s+=['</g></g>'];return '\n'.join(s)
def exit_layer():
    s=['<g id="exitSigns">']
    for e in signs:
        x,y=e['x_px'],e['y_px'];w,h=e['icon_width_px'],e['icon_height_px']
        s.append(f'<g class="exit-sign" data-sign="{e["sign_id"]}" tabindex="0" role="button" aria-label="{html.escape(e["sign_id"]+" "+e["description"])}">')
        s.append(f'<title>{html.escape(e["sign_id"]+" — "+e["description"])}</title>')
        s.append(f'<rect class="signHit" x="{x-w/2-2:.3f}" y="{y-h/2-2:.3f}" width="{w+4:.3f}" height="{h+4:.3f}" fill="transparent"/>')
        s.append(f'<image href="{e["icon_data_url"]}" x="{x-w/2:.3f}" y="{y-h/2:.3f}" width="{w:.3f}" height="{h:.3f}"/>')
        s.append('</g>')
    s.append('</g><g id="exitSignIds" font-family="Arial,sans-serif" font-size="6.8" font-weight="700" text-anchor="middle" fill="#066b27" paint-order="stroke" stroke="white" stroke-width="2.4" stroke-linejoin="round" pointer-events="none">')
    for e in signs:
        x=e['x_px']+e['label_offset'][0];y=e['y_px']+e['label_offset'][1]
        s.append(f'<text x="{x:.3f}" y="{y:.3f}">ES-{e["number"]:02}</text>')
    s.append('</g>');return '\n'.join(s)
extra=compass_layer()+exit_layer()
svg=(OUT/'EduCity_F3_Traced_Plan.svg').read_text().replace('</svg>',extra+'</svg>')
(OUT/'EduCity_F3_Traced_Plan.svg').write_text(svg)
# Preserve the satellite attribution in the complete captured viewport.
sat_url = satellite.find("{http://www.w3.org/2000/svg}image").get("href")
sw,sh=sat_im
inside=re.sub(r'^<svg[^>]*>','',svg).removesuffix('</svg>')
inside=re.sub(r'<rect x="-108" y="-25" width="764" height="851" fill="white"/>','',inside,count=1)
sat_svg=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {sw} {sh}" width="{sw}" height="{sh}"><image href="{sat_url}" x="0" y="0" width="{sw}" height="{sh}"/><g transform="{matrix_svg}" opacity=".76">{inside}</g><rect x="490" y="66" width="625" height="55" rx="5" fill="white" fill-opacity=".94"/><text x="504" y="88" font-family="Arial,sans-serif" font-size="15" font-weight="700" fill="#17374c">EduCity F3 · visual satellite alignment · {len(signs)} corrected exit signs</text><text x="504" y="107" font-family="Arial,sans-serif" font-size="12" fill="#496577">North up · approximate roof-axis match · no surveyed coordinates</text></svg>'
(OUT/'EduCity_F3_Satellite_Alignment.svg').write_text(sat_svg)

# CAD sign positions and an oriented compass arrow use the same local coordinates.
dxf=(OUT/'EduCity_F3_Region_Outlines.dxf').read_text();tail='0\nENDSEC\n0\nEOF\n';assert dxf.endswith(tail)
entities=[]
for s in signs:
    entities+=['0','POINT','8','EXIT_SIGNS','10',str(s['x_px']),'20',str(-s['y_px']),'30','0',
       '0','TEXT','8','EXIT_SIGN_IDS','10',str(s['x_px']+8),'20',str(-s['y_px']),'30','0','40','5','1',s['sign_id']]
v=mapdir(0)*30
entities+=['0','LINE','8','NORTH_COMPASS','10','-52','20','-108','30','0','11',str(-52+v[0]),'21',str(-108-v[1]),'31','0',
 '0','TEXT','8','NORTH_COMPASS','10',str(-52+v[0]),'20',str(-108-v[1]),'30','0','40','7','1','N']
(OUT/'EduCity_F3_Region_Outlines.dxf').write_text(dxf[:-len(tail)]+'\n'.join(entities)+'\n'+tail)

page=(OUT/'EduCity_F3_Trace_Review.html').read_text()
page=page.replace('</svg>',extra+'</svg>',1)
# Wrap plan layers so the same geometry can be placed in a north-up satellite view.
opening='<rect x="-108" y="-25" width="764" height="851" fill="white"/>'
assert opening in page
paper=f'<image id="satellite" href="{sat_url}" x="0" y="0" width="{sw}" height="{sh}" style="display:none"/><rect id="planPaper" x="-108" y="-25" width="764" height="851" fill="white"/><g id="scene">'
page=page.replace(opening,paper,1).replace('</svg>','</g></svg>',1)
controls='''<div class="control"><label for="viewMode"><b>View</b></label><select id="viewMode" style="width:100%;margin-top:7px"><option value="plan">Floor plan + compass</option><option value="satellite">Satellite match · north up</option></select></div><div class="control"><label><input id="showExits" type="checkbox" checked> Exit signs (15)</label></div><div class="control"><label><input id="showExitIds" type="checkbox" checked> Exit-sign IDs</label></div><div class="control"><label><input id="showCompass" type="checkbox" checked> Compass and subtle direction cross</label></div>'''
page=page.replace('<div class="control"><label><input id="showZones"',controls+'<div class="control"><label><input id="showZones"',1)
controls=controls.replace('Exit signs (15)',f'Exit signs ({len(signs)})')
# The initial controls were inserted before their count was rewritten.
page=page.replace('Exit signs (15)',f'Exit signs ({len(signs)})')
page=page.replace('DRAFT 02 · 03 NOV 2026','DRAFT 05 · 03 NOV 2026')
page=page.replace('<b>Image coordinates only.</b> Scale and true north are unconfirmed. The Google place pin is a location reference, not a plan control point. F3 follows your floor identification.',f'<b>Satellite-matched compass.</b> Plan up faces approximately {bearing:.0f}° NE. Switch to Satellite match to inspect the fit. This is a visual roof-axis alignment; scale and geographic coordinates remain unconfirmed.')
page=page.replace('No exit signs or safe routes have been inferred.',f'The {len(signs)} exit signs follow your corrected complete image. Their original icon artwork is retained. Physical FW Adv IDs remain blank; no safe route is inferred.')
page=page.replace('Source coordinates · pixels · north unconfirmed',f'Source pixels · satellite-matched north · plan up ≈ {bearing:.0f}° NE')
page=page.replace('<div id="details">Select a polygon or a register entry below.</div>','<div id="details">Select an exit sign or a zone to inspect its record.</div><h2>Exit-sign register</h2><div id="signList" style="max-height:210px;overflow:auto"></div>')
page=page.replace('</style>','.exit-sign{cursor:pointer}.exit-sign.selected .signHit{fill:#d8ffd9;fill-opacity:.4;stroke:#066b27;stroke-width:1.4}#satellite,#planPaper{pointer-events:none}</style>')
public_signs=[{k:v for k,v in s.items() if k!='icon_data_url'} for s in signs]
js = (ROOT / 'src/exit_controls.template.js').read_text(encoding='utf-8').replace('EXIT_DATA',json.dumps(public_signs,ensure_ascii=False)).replace('MATRIX',matrix_svg).replace('SAT_WIDTH',str(sw)).replace('SAT_HEIGHT',str(sh))
page=page.replace('</script>',js+'</script>')
page=page.replace("byId('sourceOpacity').value=o;sync()","byId('sourceOpacity').value=o;['showExits','showExitIds','showCompass'].forEach(id=>byId(id).checked=b);sync();updateExtra()")
page=page.replace("byId('source').setAttribute('opacity',byId('sourceOpacity').value/100)","byId('source').setAttribute('opacity',byId('viewMode')&&byId('viewMode').value==='satellite'?0:byId('sourceOpacity').value/100)")
page=page.replace('matrixTransform(plan.getScreenCTM().inverse())','matrixTransform(byId(\'scene\').getScreenCTM().inverse())')
(OUT/'EduCity_F3_Trace_Review.html').write_text(page)

qa=json.loads((OUT/'QA.json').read_text());qa['exit_sign_count']=len(signs)
qa['exit_sign_ids_unique']=len({s['sign_id'] for s in signs})==17
qa['all_marked_icons_copied']=len(signs)==len(marked)==17
qa['corrected_exit_source']=REFERENCE_NAME
qa['middle_connector_sign_removed']=not any(s['key']=='bridge_middle' for s in signs)
qa['new_corrected_markers_present']={'room_u09','room_u17','workspace_partition'}.issubset({s['key'] for s in signs})
qa['floor_rings_and_ids_preserved']=True;qa['compass_plan_up_bearing_deg']=round(bearing,3)
qa['compass_north_maps_to_satellite_up']=bool(np.allclose((A@mapdir(0))/np.linalg.norm(A@mapdir(0)),[0,-1]))
qa['satellite_control_fit_residual_px']=residual.round(3).tolist()
qa['not_validated']=[x for x in qa['not_validated'] if x!='True north']
qa['not_validated']+=['Survey-grade orientation','Exit-sign physical commissioning and individual arrow interpretation']
(OUT/'QA.json').write_text(json.dumps(qa,indent=2))
readme=(OUT/'README.txt').read_text().replace('Draft 02 /','Draft 05 /')
readme=readme.replace('REVISION 02','REVISION 05\nThe satellite overlay reaches the complete outer roof edge, including the blue\nstreet-side roof strip. The local room geometry and exit-sign positions are preserved.\n\nREVISION 04\nThe corrected Exit sign Complete.jpg is the current exit-sign reference.\nThere are 17 signs, with provisional anticlockwise ES IDs.\nThe middle connector sign is removed, the left connector sign is repositioned,\nand the U09, U17 and P2 partition signs are included.\nOriginal icons and their displayed orientations are copied from the corrected reference.\nFW Adv id, site_id and geographic egress bearings are unassigned.\nThe floor-plan compass retains its north-up satellite roof-axis match.\nUse the View selector to inspect the north-up satellite overlay.\nThis is a visual image fit, not a surveyed footprint or geographic coordinate set.\n\nREVISION 02')
readme=readme.replace('No latitude/longitude, metric scale, true north or surveyed elevation is assigned.','No latitude/longitude, metric scale or surveyed elevation is assigned.\nNorth orientation is approximate, based on visual satellite matching.')
readme=readme.replace('No physical exit-sign positions, egress bearings or evacuation routes are invented.','Exit-sign positions are transferred from the user-marked image.\nNo geographic egress bearings or evacuation routes are invented.')
readme+=f'\nSATELLITE ALIGNMENT\nPlan up bearing: {bearing:.2f} degrees east of true north (visual).\nMatrix and visual control points are retained in Trace_Data.json.\nImage: Google Maps; imagery attribution retained in the complete screenshot.\nThe small control residual measures image fitting only, not geographic accuracy.\n'
(OUT/'README.txt').write_text(readme)
im.save(OUT/'EduCity_F3_Exit_Sign_Reference.png',format='PNG')
assert qa['compass_north_maps_to_satellite_up'] and qa['exit_sign_ids_unique']
print(json.dumps({'exit_signs':len(signs),'plan_up_bearing':bearing,'control_residual':residual.tolist()}))
