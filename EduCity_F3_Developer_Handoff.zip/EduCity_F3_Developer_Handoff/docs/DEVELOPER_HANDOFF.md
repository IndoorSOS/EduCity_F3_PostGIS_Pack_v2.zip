# Developer work order

## Objective

Maintain the EduCity F3 demo and reproduce its map and registers from the bundled source. The release baseline is the reviewed Draft 07 map with 52 regions and 17 corrected exit signs.

## Build sequence

1. Trace region polygons in local image coordinates and derive the fine linework from the original floor-plan image.
2. Transfer sign positions from the corrected annotation, crop the source icon art, number signs anticlockwise from the ICT-City connection and fit the plan to the satellite control points.
3. Apply the opaque rooftop base and zone palette in satellite view.
4. Draw the enlarged signs and the north-up compass with its subtle eight-direction cross.
5. Validate region rings and registers, render the PNG previews and hash the generated files.

`scripts/build.py` runs the stages in this order. Each stage reads and writes the build directory selected by the runner. The sources and inputs are resolved relative to the project directory.

## Acceptance checks

| Check | Expected result |
| --- | --- |
| Open the prebuilt HTML | The satellite rooftop opens with the approved zone colours and 17 visible signs |
| Switch between views | Both views show the same regions and exit positions, with the compass appropriate to the view |
| Inspect a sign | The selected marker shows the same ID, zone and description as the exit-sign register |
| Inspect a zone | The selected zone shows its record and available Finnish and English labels |
| Compare the roof | The zone fills and base are opaque, and the north-up compass shows all eight directions |
| Rebuild | The HTML, SVG, PNG, CSV, JSON and DXF files are produced, and build checks pass |

## Make a change

- **Zone or colour**. Edit the region ring, palette entry or label in `src/build_trace.py`. Inspect the corresponding row in the rebuilt zone register.
- **Exit sign**. Edit the marked icon rectangle, zone association or description in `src/add_exits_compass.py`. Verify the regenerated anticlockwise numbering before associating any firmware IDs. If the count changes, update the baseline checks and display text that specify 17.
- **Satellite alignment**. Edit the corresponding local and satellite control points in `src/add_exits_compass.py`, then inspect the roof perimeter and compass in the rebuilt preview.
- **Viewer or compass appearance**. Edit the viewer templates or the relevant rooftop and compass stages. Use the prebuilt demo to compare the visual result after rebuilding.

The geometry stage checks ring construction and tests for overlap at sampled pixel centres. The runner also checks that the 17 marker IDs match the register and that the satellite fill and compass are present. The PNG step checks JavaScript syntax and renders both previews. The acceptance checks above include browser interactions for a developer to exercise during review.

## Handoff verification

The handoff was rebuilt with Python 3.12.14 and Node.js 24.22.1 using the dependency versions in the manifests. The generated HTML, both SVGs, DXF and all three CSV files matched the reviewed Draft 07 files byte for byte. Both PNG renders matched the reviewed pixels. The JSON comparison verified the zones, exit-sign records, alignment, legend and source linework.
