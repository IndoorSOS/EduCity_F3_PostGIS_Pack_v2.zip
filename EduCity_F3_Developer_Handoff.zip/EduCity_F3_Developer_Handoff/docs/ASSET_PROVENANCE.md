# Asset provenance

| Bundled input | Source |
| --- | --- |
| `assets/floor-plan-source.png` | Original user-supplied EduCity floor-plan screenshot |
| `assets/exit-sign-reference.png` | Decoded image from the user-supplied `Exit sign Complete.jpg` reference, preserved in the approved pack |
| `assets/satellite-underlay.svg` | Satellite underlay carried forward from the reviewed EduCity alignment, with its original Google Maps imagery attribution |

The floor designation follows the supplied F3 reference. The reference names and visual alignment control points are recorded in the generated trace data. The satellite map URL is retained in `dist/EduCity_F3_Trace_Data.json`.

Keep the embedded imagery attribution in derivative previews. Record the relevant asset permissions and code licence if this package is prepared for external distribution.
