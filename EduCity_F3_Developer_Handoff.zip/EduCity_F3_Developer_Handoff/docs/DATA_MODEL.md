# EduCity F3 data model

## Coordinate frames

| Frame | Units and origin |
| --- | --- |
| Original floor-plan image | Pixels in the 1537 × 916 reference image |
| Local floor trace | Pixels, with origin at source pixel `(857, 70)`, x increasing right and y increasing down |
| Satellite viewport | Pixels in the north-up satellite reference. The six-value `alignment.svg_matrix` maps the local frame into this viewport. |
| DXF | Unitless trace pixels, with local y negated for CAD orientation |

The matrix uses SVG order `[a, b, c, d, e, f]`. The viewport point is `(a*x + c*y + e, b*x + d*y + f)`. The approximately 38.60° plan-up bearing comes from the visual alignment. The building pin in the metadata is a site reference. The per-feature longitude and latitude fields are unassigned.

## Files and records

| Output | Record content |
| --- | --- |
| `EduCity_F3_Trace_Data.json` | Metadata, reference legend, zones, source linework, exit signs and satellite alignment |
| `EduCity_F3_Zone_Register.csv` | Zone ID, category, names, status and notes |
| `EduCity_F3_Vertices.csv` | Zone and ring IDs with ordered vertices in local and source pixels |
| `EduCity_F3_Exit_Sign_Register.csv` | Sign ID, level, zone, description, local and source positions, and unassigned firmware and geographic fields |
| `EduCity_F3_Region_Outlines.dxf` | Semantic region outlines, sign points and local compass |
| `QA.json` | Build checks and the trace's validation limits |

The first ring of a zone is its perimeter. Later rings define cutouts. `source_linework_rectangles` records `[x, y, width, height, tone]` in local pixels and renders details such as stair treads, door swings and furniture. A sign's `marked_image_bbox` preserves its location in the annotated reference. `x_px` and `y_px` give its centre in local trace pixels. Its artwork is embedded in `icon_data_url` and the SVG.

IDs have a local `EDU-F3-` prefix. The 17 signs use provisional `ES-01` through `ES-17` suffixes. The numbered order is anticlockwise from the ICT-City link. Commissioned site and firmware IDs can be assigned when the physical devices are verified.
