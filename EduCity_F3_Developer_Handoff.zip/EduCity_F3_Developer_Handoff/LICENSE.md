# Licence status

The project code licence is pending the owner's selection. Record the approved licence terms here when they are decided.

Reference imagery and sign artwork are documented separately in `docs/ASSET_PROVENANCE.md`.
