# EduCity F3 developer handoff

**Release 0.7.0** · IndoorSOS · EduCity, Joukahaisenkatu 7, Turku, Finland

This package contains the source, reference inputs and built program for the reviewed EduCity third-floor map. The satellite view opens with the solid rooftop colours, all 17 corrected exit signs and the eight-direction compass. Use the view selector to switch to the floor plan, or select a zone or sign to inspect its record.

## Run the demo

Extract the ZIP and open `dist/EduCity_F3_Trace_Review.html` in a browser. The page embeds its JavaScript, styling, vector drawing and image inputs. It runs offline.

To serve the same files locally, run this command from the package directory and open `http://localhost:8000/EduCity_F3_Trace_Review.html`.

```sh
python -m http.server 8000 --directory dist
```

## Rebuild from source

The full build uses Python 3.12, Node.js 24 and npm. The shipped HTML only needs a browser. Install the build dependencies from the package directory.

```sh
python -m venv .venv
```

Activate the environment with `source .venv/bin/activate` on macOS or Linux, or `.venv\Scripts\Activate.ps1` in PowerShell. Then run:

```sh
python -m pip install -r requirements.txt
npm install
python scripts/build.py --output build
```

The build writes to a new directory after the checks pass. Choose another output path for a subsequent build. For HTML, SVG and data exports with Python alone, use `python scripts/build.py --skip-previews --output build-vector`.

## Find the source and outputs

| Path | Purpose |
| --- | --- |
| `src/build_trace.py` | Editable region rings, labels and colours, source linework, and the initial floor-plan exports |
| `src/add_exits_compass.py` | Exit-sign placements, source icon crops, visual satellite control points and coordinate transformation |
| `src/viewer.template.html` and `src/exit_controls.template.js` | Viewer layout, styles and interaction source |
| `src/apply_rooftop_cover.py` | Solid rooftop zone fill and default satellite view |
| `src/restore_signs_compass.py` | Prominent exit signs and the north-up satellite compass |
| `src/validate_geometry.py` and `scripts/build.py` | Build stages and checks for rings, registers, symbols and compass |
| `scripts/render_previews.mjs` | SVG-to-PNG export and JavaScript syntax check |
| `assets/` | Floor-plan image, corrected exit-sign reference and satellite underlay |
| `dist/` | Offline HTML, SVG and PNG views, DXF, JSON, CSV registers, QA and checksums |
| `docs/` | Developer work order, coordinate and data model, and asset provenance |

`dist/EduCity_F3_Trace_Data.json` is the machine-readable output. Edit the source stages and rebuild when making a change that must carry through the viewer and exports.

## Coordinate status

The trace uses local image pixels. The satellite overlay uses a visual affine fit to the rooftop. A surveyed metric or geographic registration and physical exit-sign commissioning are separate work. The current register leaves geographic coordinates and `FW Adv id` values blank.

See `LICENSE.md` for the code licence status and `docs/ASSET_PROVENANCE.md` for the source imagery.
